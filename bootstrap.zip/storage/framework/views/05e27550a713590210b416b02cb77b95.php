

<?php $__env->startSection('title', 'Verify Code'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrap">
    <form class="auth-card" method="POST" action="<?php echo e(route('admin.otp.verify')); ?>">
        <?php echo csrf_field(); ?>
        <h1>Enter Verification Code</h1>
        <p class="auth-sub">We've emailed a 6-digit code. It expires in 10 minutes.</p>

        <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert-error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-row">
            <label for="otp">Verification Code</label>
            <input type="text" id="otp" name="otp" inputmode="numeric" maxlength="6" required autofocus>
        </div>

        <button type="submit" class="btn-admin">Verify & Login</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\verify-otp.blade.php ENDPATH**/ ?>