<?php
    $tierColor = ['gold' => 'bg-gold-500', 'silver' => 'bg-neutral-300', 'bronze' => 'bg-[#b5763a]'][$plan->color] ?? 'bg-gold-500';
?>

<article class="plan-card relative flex h-full flex-col rounded-md border p-7 sm:p-8 <?php echo e($plan->is_featured ? 'border-gold-500/70 bg-gradient-to-b from-gold-500/[0.16] via-ink-850 to-ink-850 shadow-[0_40px_80px_-40px_rgba(212,165,55,0.55)]' : 'border-white/10 bg-ink-850'); ?>">
    <?php if($plan->is_featured): ?>
        <span class="absolute -top-3.5 left-7 rounded-full bg-gold-500 px-3.5 py-1 text-[0.7rem] font-extrabold tracking-[0.14em] text-ink-950 uppercase">Most popular</span>
    <?php endif; ?>

    <div class="flex items-center justify-between gap-4">
        <h3 class="font-display text-[2rem] leading-none text-white"><?php echo e($plan->name); ?></h3>
        <span class="inline-flex items-center gap-2 text-[0.7rem] font-bold tracking-[0.16em] text-white/50 uppercase">
            <span class="size-2.5 rounded-full <?php echo e($tierColor); ?>"></span><?php echo e($plan->color); ?>

        </span>
    </div>

    <p class="mt-7 flex items-baseline gap-1.5">
        <span class="font-display text-6xl leading-none font-extrabold text-white">₹<?php echo e(number_format($plan->price)); ?></span>
        <span class="text-sm font-semibold text-white/50"><?php echo e($plan->period); ?></span>
    </p>

    <ul class="mt-7 flex-1 space-y-3.5 border-t border-white/10 pt-7 text-[0.95rem]">
        <?php $__currentLoopData = $plan->featureList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex gap-3 text-white/80">
                <?php echo \App\Support\SiteHtml::icon('check', 'mt-1 text-sm text-gold-400'); ?>
                <span><?php echo e($feature); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <a href="<?php echo e(route('gym.book.plan', $plan)); ?>" class="btn mt-8 w-full <?php echo e($plan->is_featured ? 'btn-gold' : 'btn-ghost'); ?>">
        <?php echo e($plan->button_text); ?> <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?>
    </a>
</article>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/partials/site/plan-card.blade.php ENDPATH**/ ?>