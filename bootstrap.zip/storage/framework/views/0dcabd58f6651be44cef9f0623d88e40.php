<?php $__env->startSection('title', 'Gallery — Inside ChampionClub | Gym in ' . config('gym.address.locality')); ?>
<?php $__env->startSection('description', 'Take a look inside ChampionClub ' . config('gym.address.locality') . ': the reception, lounge, weights floor, cardio zone, changing rooms, lockers and washrooms.'); ?>
<?php $__env->startSection('og_image', 'page-facilities'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5045da81eea10cd01496aa62d8386994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5045da81eea10cd01496aa62d8386994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-hero','data' => ['image' => 'page-facilities','eyebrow' => 'Gallery','title' => 'Take a look inside.','crumb' => 'Gallery']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'page-facilities','eyebrow' => 'Gallery','title' => 'Take a look inside.','crumb' => 'Gallery']); ?>
    From the reception to the lockers — see the spaces you'll train in before you visit.
     <?php $__env->slot('actions', null, []); ?> 
        <a href="<?php echo e(route('gym.trial')); ?>" class="btn btn-gold">Book a free trial <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></a>
        <a href="<?php echo e($gymContact->mapsUrl()); ?>" target="_blank" rel="noopener" class="btn btn-ghost"><?php echo \App\Support\SiteHtml::icon('pin', ''); ?> Visit us</a>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $attributes = $__attributesOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__attributesOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $component = $__componentOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__componentOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>

<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap">
        <?php if($photos->isEmpty()): ?>
            <div class="mx-auto max-w-xl border border-white/10 bg-ink-900 p-10 text-center">
                <span class="icon-tile"><?php echo \App\Support\SiteHtml::icon('sparkle', ''); ?></span>
                <h2 class="display-md mt-6 text-white">Photos will be added soon.</h2>
                <a href="<?php echo e(route('gym.facilities')); ?>" class="btn btn-gold mt-8">Explore the facilities</a>
            </div>
        <?php else: ?>
            <div class="gallery-grid" data-gallery>
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure class="gallery-item" data-reveal style="--reveal-delay: <?php echo e(($loop->index % 3) * 0.06); ?>s">
                        <button type="button" class="gallery-open group" data-gallery-item data-src="<?php echo e($photo->url()); ?>" data-alt="<?php echo e($photo->alt); ?>" data-caption="<?php echo e($photo->caption); ?>" aria-label="Open photo: <?php echo e($photo->alt); ?>">
                            <img src="<?php echo e($photo->url()); ?>" alt="<?php echo e($photo->alt); ?>" width="<?php echo e($photo->width ?: 1400); ?>" height="<?php echo e($photo->height ?: 933); ?>" loading="<?php echo e($loop->index < 3 ? 'eager' : 'lazy'); ?>" decoding="async" class="absolute inset-0 size-full object-cover transition duration-700 group-hover:scale-[1.04]">
                            <span class="gallery-zoom" aria-hidden="true"><?php echo \App\Support\SiteHtml::icon('external', ''); ?></span>
                            <?php if($photo->caption): ?>
                                <span class="gallery-caption"><?php echo e($photo->caption); ?></span>
                            <?php endif; ?>
                        </button>
                    </figure>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php if($photos->isNotEmpty()): ?>
    <dialog class="gallery-lightbox" data-lightbox aria-label="Photo viewer">
        <div class="gallery-lightbox-inner">
            <button type="button" class="gallery-lightbox-btn gallery-lightbox-close" data-lightbox-close aria-label="Close"><?php echo \App\Support\SiteHtml::icon('close', ''); ?></button>
            <button type="button" class="gallery-lightbox-btn gallery-lightbox-prev" data-lightbox-prev aria-label="Previous photo"><?php echo \App\Support\SiteHtml::icon('arrow', 'rotate-180'); ?></button>
            <figure class="gallery-lightbox-figure">
                <img src="" alt="" data-lightbox-img>
                <figcaption data-lightbox-caption></figcaption>
            </figure>
            <button type="button" class="gallery-lightbox-btn gallery-lightbox-next" data-lightbox-next aria-label="Next photo"><?php echo \App\Support\SiteHtml::icon('arrow', ''); ?></button>
            <p class="gallery-lightbox-count" data-lightbox-count></p>
        </div>
    </dialog>
<?php endif; ?>

<?php echo $__env->make('partials.site.cta-band', ['image' => 'gallery-1', 'title' => 'Like what you see?', 'text' => 'Book a free trial and see the floor in person.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/gallery.blade.php ENDPATH**/ ?>