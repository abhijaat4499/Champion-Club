<?php
    $highlights = $service->highlightList();
    $blocks = $service->descriptionBlocks();
    $bookUrl = route('gym.book.service', $service);
?>

<?php $__env->startSection('title', $service->title . ' | ' . config('gym.name') . ' ' . config('gym.address.locality')); ?>
<?php $__env->startSection('description', $service->summary); ?>
<?php $__env->startSection('og_image', \App\Models\Service::FALLBACK_IMAGE); ?>

<?php $__env->startSection('content'); ?>


<section class="relative isolate flex min-h-[62svh] items-end overflow-hidden bg-ink-950 pt-36 pb-14 sm:min-h-[66svh] lg:min-h-[72vh] lg:pb-20">
    <?php if($service->imageUrl()): ?>
        <img src="<?php echo e($service->imageUrl()); ?>" style="<?php echo e($service->heroFocus()); ?>" alt="" width="1600" height="1000" fetchpriority="high" decoding="async" class="absolute inset-0 -z-20 size-full object-cover animate-ken-burns">
    <?php else: ?>
        <?php echo \App\Support\SiteHtml::img(\App\Models\Service::FALLBACK_IMAGE, 'absolute inset-0 -z-20 size-full object-cover animate-ken-burns', true); ?>
    <?php endif; ?>
    <div class="absolute inset-0 -z-10 bg-gradient-to-t from-ink-950 via-ink-950/70 to-ink-950/35"></div>
    <div class="absolute inset-y-0 left-0 -z-10 w-2/3 bg-gradient-to-r from-ink-950/80 to-transparent"></div>

    <div class="wrap">
        <div class="max-w-3xl">
            <nav aria-label="Breadcrumb" class="mb-6 text-xs font-semibold tracking-[0.18em] text-white/55 uppercase">
                <ol class="flex flex-wrap items-center gap-2">
                    <li><a href="<?php echo e(url('/')); ?>" class="transition hover:text-gold-400">Home</a></li>
                    <li aria-hidden="true">/</li>
                    <li><a href="<?php echo e(route('gym.services')); ?>" class="transition hover:text-gold-400">Services</a></li>
                    <li aria-hidden="true">/</li>
                    <li aria-current="page" class="text-gold-400"><?php echo e($service->title); ?></li>
                </ol>
            </nav>
            <div class="flex items-center gap-4">
                <span class="icon-tile"><?php echo \App\Support\SiteHtml::icon($service->iconName(), ''); ?></span>
                <p class="eyebrow">Service</p>
            </div>
            <h1 class="<?php echo e(mb_strlen($service->title) > 28 ? 'display-lg' : 'display-xl'); ?> mt-6 text-white"><?php echo e($service->title); ?></h1>
            <p class="lead mt-6 max-w-2xl text-white/75"><?php echo e($service->summary); ?></p>

            <?php if($highlights): ?>
                <ul class="mt-8 flex flex-wrap gap-2.5 text-[0.85rem] font-semibold text-white">
                    <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-4 py-2 backdrop-blur">
                            <?php echo \App\Support\SiteHtml::icon('check', 'text-gold-400'); ?> <?php echo e($highlight); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <div class="mt-9 flex flex-wrap gap-3">
                <a href="<?php echo e($bookUrl); ?>" class="btn btn-gold">Book <?php echo e($service->title); ?> <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></a>
                <a href="<?php echo e($gymContact->whatsappUrl($booking['whatsapp'])); ?>" target="_blank" rel="noopener" class="btn btn-ghost"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> Ask on WhatsApp</a>
            </div>
        </div>
    </div>
</section>


<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap">
        <div class="grid gap-12 lg:grid-cols-12 lg:gap-16">
            <div class="lg:sticky lg:top-32 lg:col-span-5 lg:self-start" data-reveal="left">
                <div class="zoom-media relative overflow-hidden rounded-sm">
                    <?php if($service->imageUrl()): ?>
                        <img src="<?php echo e($service->imageUrl()); ?>" style="<?php echo e($service->imageFocus()); ?>" alt="<?php echo e($service->title); ?>" width="800" height="1000" loading="lazy" decoding="async" class="aspect-[4/3] w-full object-cover lg:aspect-[4/5]">
                    <?php else: ?>
                        <?php echo \App\Support\SiteHtml::img(\App\Models\Service::FALLBACK_IMAGE, 'aspect-[4/3] w-full lg:aspect-[4/5]', false, $service->title); ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="lg:col-span-7">
                <p class="eyebrow !text-gold-700" data-reveal>About this service</p>
                <h2 class="display-lg mt-5" data-reveal>What to expect.</h2>
                <div class="service-copy mt-8" data-reveal>
                    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($block['type'] === 'heading'): ?>
                            <h3><?php echo e($block['text']); ?></h3>
                        <?php else: ?>
                            <p><?php echo e($block['text']); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="mt-16 flex flex-col gap-6 rounded-md bg-ink-950 p-8 text-white sm:p-10 lg:flex-row lg:items-center lg:justify-between" data-reveal>
            <div>
                <p class="eyebrow">Ready to start?</p>
                <h2 class="display-md mt-4">Book <?php echo e($service->title); ?> today.</h2>
                <p class="mt-3 max-w-xl text-white/65">Share your details and our team will call to fix a time that suits you.</p>
            </div>
            <div class="flex shrink-0 flex-wrap gap-3">
                <a href="<?php echo e($bookUrl); ?>" class="btn btn-gold">Book <?php echo e($service->title); ?> <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></a>
                <a href="<?php echo e($gymContact->callUrl()); ?>" class="btn btn-ghost"><?php echo \App\Support\SiteHtml::icon('phone', ''); ?> Call us</a>
            </div>
        </div>
    </div>
</section>

<?php if($others->isNotEmpty()): ?>
    <section class="border-t border-ink-950/10 bg-bone-50 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
        <div class="wrap">
            <div class="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between" data-reveal>
                <div>
                    <p class="eyebrow !text-gold-700">More services</p>
                    <h2 class="display-lg mt-5">Mix it up.</h2>
                </div>
                <a href="<?php echo e(route('gym.services')); ?>" class="link-arrow !text-gold-700">All services <?php echo \App\Support\SiteHtml::icon('arrow', ''); ?></a>
            </div>
            <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-reveal style="--reveal-delay: <?php echo e($loop->index * 0.08); ?>s">
                        <?php echo $__env->make('partials.site.service-card', ['service' => $other], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/service.blade.php ENDPATH**/ ?>