<?php $__env->startSection('title', 'Gallery'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Gallery','icon' => 'gallery']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Gallery','icon' => 'gallery']); ?>
        <a href="<?php echo e(route('gym.gallery')); ?>" class="btn-logout" target="_blank" rel="noopener">View on website</a>
        <a href="<?php echo e(route('admin.gallery.create')); ?>" class="btn-admin-small">+ Upload photos</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <p class="settings-note">Photos shown on the Gallery page. Drag cards to reorder. Descriptive alt text helps image SEO.</p>

    <?php if($photos->isEmpty()): ?>
        <div class="table-empty gallery-empty">No photos yet. Upload your first photos to show them on the website.</div>
    <?php else: ?>
        <form method="POST" action="<?php echo e(route('admin.gallery.bulk-destroy')); ?>" id="bulkForm" onsubmit="return confirm('Delete the selected photos?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <div class="gallery-toolbar">
                <label class="gallery-select-all">
                    <input type="checkbox" id="selectAll"> Select all
                </label>
                <button type="submit" class="btn-delete" id="bulkDelete" disabled>Delete selected</button>
                <span class="gallery-save-state" id="orderState" aria-live="polite"></span>
            </div>

            <div class="gallery-admin-grid" id="galleryGrid" data-reorder-url="<?php echo e(route('admin.gallery.reorder')); ?>">
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="gallery-card" draggable="true" data-id="<?php echo e($photo->id); ?>">
                        <div class="gallery-card-media">
                            <img src="<?php echo e($photo->url()); ?>" alt="<?php echo e($photo->alt); ?>" loading="lazy">
                            <?php if (! ($photo->is_active)): ?>
                                <span class="status-chip status-hidden gallery-card-status">Hidden</span>
                            <?php endif; ?>
                        </div>
                        <div class="gallery-card-body">
                            <div class="gallery-card-title">
                                <span class="gallery-drag" aria-hidden="true">⋮⋮</span>
                                <input type="checkbox" name="ids[]" value="<?php echo e($photo->id); ?>" class="gallery-check" aria-label="Select photo <?php echo e($loop->iteration); ?>">
                                <span class="gallery-alt" title="<?php echo e($photo->alt); ?>"><?php echo e($photo->alt); ?></span>
                            </div>
                            <p class="gallery-caption-text"><?php echo e($photo->caption ?: '—'); ?></p>
                            <div class="gallery-card-foot">
                                <span class="gallery-order" data-order>#<?php echo e($loop->iteration); ?></span>
                                <div class="row-actions">
                                    <a href="<?php echo e(route('admin.gallery.edit', $photo)); ?>" class="btn-edit">Edit</a>
                                    <button type="submit" form="delete-<?php echo e($photo->id); ?>" class="btn-delete">Delete</button>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </form>

        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="POST" action="<?php echo e(route('admin.gallery.destroy', $photo)); ?>" id="delete-<?php echo e($photo->id); ?>" onsubmit="return confirm('Delete this photo?');" hidden>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>

<script>
    (function () {
        const grid = document.getElementById('galleryGrid');
        if (!grid) return;

        const selectAll = document.getElementById('selectAll');
        const bulkDelete = document.getElementById('bulkDelete');
        const state = document.getElementById('orderState');
        const checks = () => [...grid.querySelectorAll('.gallery-check')];

        const syncBulk = () => {
            const selected = checks().filter((c) => c.checked).length;
            bulkDelete.disabled = selected === 0;
            bulkDelete.textContent = selected ? `Delete selected (${selected})` : 'Delete selected';
            selectAll.checked = selected > 0 && selected === checks().length;
        };

        selectAll.addEventListener('change', () => {
            checks().forEach((c) => { c.checked = selectAll.checked; });
            syncBulk();
        });
        grid.addEventListener('change', (e) => { if (e.target.classList.contains('gallery-check')) syncBulk(); });

        let dragged = null;

        grid.addEventListener('dragstart', (e) => {
            dragged = e.target.closest('.gallery-card');
            if (!dragged) return;
            dragged.classList.add('is-dragging');
            e.dataTransfer.effectAllowed = 'move';
        });

        grid.addEventListener('dragover', (e) => {
            e.preventDefault();
            const over = e.target.closest('.gallery-card');
            if (!dragged || !over || over === dragged) return;
            const rect = over.getBoundingClientRect();
            const after = (e.clientY - rect.top) > rect.height / 2 || (e.clientX - rect.left) > rect.width / 2;
            grid.insertBefore(dragged, after ? over.nextSibling : over);
        });

        grid.addEventListener('dragend', () => {
            if (!dragged) return;
            dragged.classList.remove('is-dragging');
            dragged = null;
            save();
        });

        function save() {
            const cards = [...grid.querySelectorAll('.gallery-card')];
            cards.forEach((card, i) => { card.querySelector('[data-order]').textContent = '#' + (i + 1); });
            state.textContent = 'Saving order…';

            fetch(grid.dataset.reorderUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('#bulkForm input[name="_token"]').value,
                },
                body: JSON.stringify({ ids: cards.map((card) => Number(card.dataset.id)) }),
            })
                .then((r) => { state.textContent = r.ok ? 'Order saved' : 'Could not save order'; })
                .catch(() => { state.textContent = 'Could not save order'; });
        }
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>