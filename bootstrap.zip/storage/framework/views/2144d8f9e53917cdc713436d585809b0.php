<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Services','icon' => 'services']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Services','icon' => 'services']); ?>
        <a href="<?php echo e(route('gym.services')); ?>" class="btn-logout" target="_blank" rel="noopener">View on website</a>
        <a href="<?php echo e(route('admin.services.create')); ?>" class="btn-admin-small">+ Add Service</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="admin-table">
        <thead>
            <tr>
                <th class="col-order">Order</th>
                <th>Service</th>
                <th>Summary</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="col-order"><span class="order-chip"><?php echo e($service->display_order); ?></span></td>
                    <td>
                        <div class="person-cell">
                            <?php if($service->image): ?>
                                <img src="<?php echo e($service->imageUrl()); ?>" alt="<?php echo e($service->title); ?>" class="service-thumb">
                            <?php else: ?>
                                <span class="service-thumb service-thumb-empty"><?php echo e(mb_strtoupper(mb_substr($service->title, 0, 1))); ?></span>
                            <?php endif; ?>
                            <div>
                                <span class="person-name"><?php echo e($service->title); ?></span>
                                <span class="person-sub">/services/<?php echo e($service->slug); ?></span>
                            </div>
                        </div>
                    </td>
                    <td class="col-bio"><?php echo e(\Illuminate\Support\Str::limit($service->summary, 90)); ?></td>
                    <td>
                        <span class="status-chip status-<?php echo e($service->is_active ? 'live' : 'hidden'); ?>"><?php echo e($service->is_active ? 'Live' : 'Hidden'); ?></span>
                    </td>
                    <td class="text-right">
                        <div class="row-actions">
                            <?php if($service->is_active): ?>
                                <a href="<?php echo e(route('gym.service', $service)); ?>" class="btn-edit" target="_blank" rel="noopener">View</a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('admin.services.edit', $service)); ?>" class="btn-edit">Edit</a>

                            <form action="<?php echo e(route('admin.services.destroy', $service)); ?>" method="POST"
                                  onsubmit="return confirm('Delete this service?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="table-empty">No services yet. Add your first service to show it on the website.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/services/index.blade.php ENDPATH**/ ?>