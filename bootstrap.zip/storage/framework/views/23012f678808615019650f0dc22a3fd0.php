<?php
    $service = $service ?? null;
?>

<div class="form-row">
    <label for="title">Service name</label>
    <input type="text" id="title" name="title" value="<?php echo e(old('title', $service->title ?? '')); ?>" placeholder="e.g. Strength & Conditioning" maxlength="120" required>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="slug">Page URL <small>(optional)</small></label>
    <input type="text" id="slug" name="slug" value="<?php echo e(old('slug', $service->slug ?? '')); ?>" placeholder="e.g. strength-conditioning" maxlength="140">
    <small>Website link: <?php echo e(url('/services')); ?>/<strong><?php echo e(old('slug', $service->slug ?? 'service-name')); ?></strong> — leave empty to create it from the name.</small>
    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="icon">Icon</label>
    <select id="icon" name="icon" required>
        <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('icon', $service->icon ?? 'dumbbell') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="summary">Short summary</label>
    <input type="text" id="summary" name="summary" value="<?php echo e(old('summary', $service->summary ?? '')); ?>" placeholder="One line shown on the service card" maxlength="255" required>
    <?php $__errorArgs = ['summary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="description">Description</label>
    <textarea id="description" name="description" rows="6" maxlength="5000" required><?php echo e(old('description', $service->description ?? '')); ?></textarea>
    <small>Leave an empty line between paragraphs.</small>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="highlights">Highlights <small>(optional, one per line)</small></label>
    <textarea id="highlights" name="highlights" rows="4" maxlength="2000" placeholder="45-minute sessions&#10;Beginner friendly"><?php echo e(old('highlights', $service->highlights ?? '')); ?></textarea>
    <?php $__errorArgs = ['highlights'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="image">Image <small>(optional)</small></label>
    <?php if($service?->image): ?>
        <img src="<?php echo e($service->imageUrl()); ?>" alt="<?php echo e($service->title); ?>" class="service-thumb-preview">
    <?php endif; ?>
    <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp">
    <small><?php echo e(\App\Support\ImageUpload::HINT); ?> A landscape photo works best.</small>
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="image_position">Image focus</label>
    <select id="image_position" name="image_position">
        <?php $__currentLoopData = \App\Models\Service::IMAGE_POSITIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('image_position', $service->image_position ?? 'center') === $value ? 'selected' : ''); ?>><?php echo e($position['label']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <small>Which part of the photo stays visible when it is cropped. Use "Upper" for tall photos where the face is near the top.</small>
    <?php $__errorArgs = ['image_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php if($service?->image): ?>
    <div class="checkbox-field">
        <input type="checkbox" id="remove_image" name="remove_image" value="1">
        <label for="remove_image">Remove current image</label>
    </div>
<?php endif; ?>

<div class="form-row">
    <label for="display_order">Display order</label>
    <input type="number" id="display_order" name="display_order" min="0" value="<?php echo e(old('display_order', $service->display_order ?? 0)); ?>" required>
    <?php $__errorArgs = ['display_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="checkbox-field">
    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : ($service->is_active ?? true)) ? 'checked' : ''); ?>>
    <label for="is_active">Show on website</label>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/services/_form.blade.php ENDPATH**/ ?>