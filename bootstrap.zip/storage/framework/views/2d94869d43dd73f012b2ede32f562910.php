<?php
    $review = $review ?? null;
?>

<div class="form-row">
    <label for="name">Member name</label>
    <input type="text" id="name" name="name" value="<?php echo e(old('name', $review->name ?? '')); ?>" maxlength="80" required>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="since">Member since <small>(optional, year)</small></label>
    <input type="text" id="since" name="since" value="<?php echo e(old('since', $review->since ?? '')); ?>" inputmode="numeric" maxlength="4" placeholder="2024">
    <?php $__errorArgs = ['since'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="quote">Review</label>
    <textarea id="quote" name="quote" rows="5" maxlength="600" required><?php echo e(old('quote', $review->quote ?? '')); ?></textarea>
    <?php $__errorArgs = ['quote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="rating">Rating</label>
    <select id="rating" name="rating" required>
        <?php for($stars = 5; $stars >= 1; $stars--): ?>
            <option value="<?php echo e($stars); ?>" <?php echo e((int) old('rating', $review->rating ?? 5) === $stars ? 'selected' : ''); ?>><?php echo e($stars); ?> <?php echo e($stars === 1 ? 'star' : 'stars'); ?></option>
        <?php endfor; ?>
    </select>
    <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="display_order">Display order</label>
    <input type="number" id="display_order" name="display_order" min="0" value="<?php echo e(old('display_order', $review->display_order ?? 0)); ?>" required>
    <?php $__errorArgs = ['display_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="checkbox-field">
    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : ($review->is_active ?? true)) ? 'checked' : ''); ?>>
    <label for="is_active">Show on website</label>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\testimonials\_form.blade.php ENDPATH**/ ?>