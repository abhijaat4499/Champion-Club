<?php
    $total = $heroSlides->count();
?>

<section class="hero-slider relative bg-ink-950" aria-roledescription="carousel" aria-label="ChampionClub highlights">
    <div class="swiper">
        <div class="swiper-wrapper">
            <?php $__currentLoopData = $heroSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $pattern = $slide->patternName();
                    $points = $slide->pointList();
                    $heading = $loop->first ? 'h1' : 'h2';
                    $headingClass = $pattern === 'card' ? 'display-lg' : 'display-xl';
                ?>
                <div class="swiper-slide" role="group" aria-roledescription="slide" aria-label="<?php echo e($loop->iteration); ?> of <?php echo e($total); ?>">
                    <div class="hero-media absolute inset-0">
                        <?php if($slide->image): ?>
                            <picture>
                                <?php if($slide->image_mobile): ?>
                                    <source media="(max-width: 640px)" srcset="<?php echo e(asset('storage/' . $slide->image_mobile)); ?>">
                                <?php endif; ?>
                                <img src="<?php echo e(asset('storage/' . $slide->image)); ?>" alt="" width="1920" height="1080" style="<?php echo e($slide->focus()); ?>" decoding="async" <?php if($loop->first): ?> fetchpriority="high" <?php else: ?> loading="lazy" <?php endif; ?>>
                            </picture>
                        <?php elseif($slide->site_image): ?>
                            <?php echo \App\Support\SiteHtml::img($slide->site_image, '', $loop->first); ?>
                        <?php endif; ?>
                    </div>

                    <?php if($pattern === 'card'): ?>
                        <div class="absolute inset-0 bg-gradient-to-l from-ink-950/90 via-ink-950/45 to-ink-950/10"></div>
                        <div class="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/40"></div>
                    <?php elseif($pattern === 'center'): ?>
                        <div class="absolute inset-0 bg-ink-950/45"></div>
                        <div class="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/30 to-ink-950/50"></div>
                    <?php else: ?>
                        <div class="absolute inset-0 bg-gradient-to-r from-ink-950/95 via-ink-950/60 to-ink-950/10"></div>
                        <div class="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/40"></div>
                    <?php endif; ?>

                    <div class="wrap relative flex w-full flex-1 pt-28 pb-44 lg:pt-40 lg:pb-32 <?php echo e($pattern === 'center' ? 'items-end justify-center text-center' : ($pattern === 'card' ? 'items-end justify-end lg:items-center' : 'items-end lg:items-center')); ?>">
                        <div class="hero-copy <?php echo e($pattern === 'card' ? 'max-w-xl border-l-4 border-gold-500 bg-ink-950/70 p-6 backdrop-blur-md sm:p-10' : ($pattern === 'center' ? 'flex max-w-4xl flex-col items-center' : 'max-w-3xl')); ?>">
                            <?php if($slide->label): ?>
                                <p class="eyebrow"><?php echo e($slide->label); ?></p>
                            <?php endif; ?>

                            <<?php echo e($heading); ?> class="<?php echo e($headingClass); ?> <?php echo e($slide->label ? 'mt-5' : ''); ?> text-white"><?php echo e($slide->titleHtml()); ?></<?php echo e($heading); ?>>

                            <?php if($slide->description): ?>
                                <p class="<?php echo e($pattern === 'card' ? 'mt-5 leading-relaxed text-white/75' : 'lead mt-6 max-w-xl text-white/75 max-sm:hidden'); ?>"><?php echo e($slide->description); ?></p>
                            <?php endif; ?>

                            <?php if($points && $slide->points_style === 'capsules'): ?>
                                <ul class="mt-7 flex flex-wrap gap-2.5 text-[0.8rem] font-semibold text-white max-sm:hidden <?php echo e($pattern === 'center' ? 'justify-center' : ''); ?>">
                                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="rounded-full border border-white/25 bg-white/5 px-4 py-2 backdrop-blur"><?php echo e($point); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php elseif($points && $slide->points_style === 'checks'): ?>
                                <ul class="mt-6 grid gap-2.5 text-sm text-white/85 max-sm:hidden <?php echo e($pattern === 'center' ? 'justify-items-center' : ''); ?>">
                                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="flex items-center gap-3"><?php echo \App\Support\SiteHtml::icon('check', 'text-gold-400'); ?> <?php echo e($point); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>

                            <?php if($slide->buttons()): ?>
                                <div class="mt-9 flex flex-wrap gap-3 max-sm:mt-7 max-sm:[&>.btn]:px-4 <?php echo e($pattern === 'center' ? 'justify-center' : ''); ?>">
                                    <?php $__currentLoopData = $slide->buttons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $icon = \App\Models\HeroSlide::targetIcon($button['target']); ?>
                                        <a href="<?php echo e(\App\Models\HeroSlide::targetUrl($button['target'])); ?>"
                                           class="btn <?php echo e($loop->first ? 'btn-gold' : 'btn-ghost'); ?>"
                                           <?php if(\App\Models\HeroSlide::isExternal($button['target'])): ?> target="_blank" rel="noopener" <?php endif; ?>>
                                            <?php if($icon): ?> <?php echo \App\Support\SiteHtml::icon($icon, ''); ?> <?php endif; ?>
                                            <?php echo e($button['text']); ?>

                                            <?php if(! $icon && $loop->first): ?> <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?> <?php endif; ?>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            <?php if($pattern === 'spotlight'): ?>
                                <a href="<?php echo e($gymContact->callUrl()); ?>" class="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-white/70 transition hover:text-gold-400 max-sm:hidden">
                                    <?php echo \App\Support\SiteHtml::icon('phone', 'text-gold-500'); ?> Call us: <?php echo e($gymContact->displayPhone()); ?>

                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php if($total > 1): ?>
        <div class="absolute inset-x-0 bottom-0 z-10 pb-[5.5rem] lg:pb-10">
            <div class="wrap flex items-end gap-5 sm:gap-8">
                <p class="font-display text-white" aria-hidden="true">
                    <span class="text-4xl font-extrabold" data-hero-current>01</span><span class="text-lg text-white/45"> / <?php echo e(str_pad($total, 2, '0', STR_PAD_LEFT)); ?></span>
                </p>
                <div class="grid flex-1 gap-3 sm:gap-5" style="grid-template-columns: repeat(<?php echo e($total); ?>, minmax(0, 1fr))">
                    <?php $__currentLoopData = $heroSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="group text-left" data-hero-go aria-label="Show slide <?php echo e($loop->iteration); ?>: <?php echo e($slide->tab); ?>">
                            <span class="mb-2 hidden truncate text-xs font-bold tracking-[0.18em] text-white/55 uppercase transition group-hover:text-white sm:block"><?php echo e($slide->tab); ?></span>
                            <span class="hero-bullet block <?php echo e($loop->first ? 'is-active' : ''); ?>"><span></span></span>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="flex items-center gap-2">
                    <button type="button" class="carousel-btn carousel-btn-dark size-11 max-sm:hidden" data-hero-prev aria-label="Previous slide"><?php echo \App\Support\SiteHtml::icon('arrow', 'rotate-180'); ?></button>
                    <button type="button" class="carousel-btn carousel-btn-dark size-11 max-sm:hidden" data-hero-next aria-label="Next slide"><?php echo \App\Support\SiteHtml::icon('arrow', ''); ?></button>
                    <button type="button" class="carousel-btn carousel-btn-dark size-11" data-hero-toggle aria-pressed="false" aria-label="Pause slideshow">
                        <?php echo \App\Support\SiteHtml::icon('pause', '', 'data-icon-pause'); ?><?php echo \App\Support\SiteHtml::icon('play', '', 'data-icon-play hidden'); ?>
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?>
</section>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/partials/site/hero-slider.blade.php ENDPATH**/ ?>