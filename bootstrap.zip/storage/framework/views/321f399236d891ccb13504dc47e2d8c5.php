<div style="font-family: sans-serif; max-width: 480px; margin: 0 auto; padding: 32px;">
    <h2 style="color: #14100d;"><?php echo e($mailSubject); ?></h2>
    <p>Your one-time verification code is:</p>
    <p style="font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #c9a227;"><?php echo e($otp); ?></p>
    <p>This code will expire in 10 minutes. If you didn't request this, ignore this email.</p>
</div><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/emails/otp.blade.php ENDPATH**/ ?>