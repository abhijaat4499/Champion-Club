<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Enquiries','icon' => 'dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Enquiries','icon' => 'dashboard']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <div class="dashboard-section">

        
        <form method="GET" action="<?php echo e(route('admin.dashboard')); ?>" class="filter-bar">
            <div class="filter-field">
                <label for="from">From</label>
                <input type="date" id="from" name="from" value="<?php echo e($from); ?>">
            </div>

            <div class="filter-field">
                <label for="to">To</label>
                <input type="date" id="to" name="to" value="<?php echo e($to); ?>">
            </div>

            <button type="submit" class="btn-admin-small">Apply filter</button>

            <?php if($from || $to || $sort !== 'newest'): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-logout">Reset</a>
            <?php endif; ?>

            <div class="filter-field filter-sort">
                <label for="sort">Sort by</label>
                <select id="sort" name="sort" onchange="this.form.submit()">
                    <?php $__currentLoopData = $sortOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php echo e($sort === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>

        <?php if($errors->any()): ?>
            <div class="alert-error"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>Lead</th>
                    <th>Phone</th>
                    <th>Interest</th>
                    <th>Message</th>
                    <th class="text-right">Received</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <span class="person-name"><?php echo e($enquiry->name); ?></span>
                            <span class="person-sub"><?php echo e($enquiry->email); ?></span>
                        </td>
                        <td class="nowrap">
                            <?php if($call = $enquiry->callableNumber()): ?>
                                <a href="tel:<?php echo e($call); ?>" class="phone-call" title="Call <?php echo e($enquiry->name); ?>" aria-label="Call <?php echo e($enquiry->name); ?> on <?php echo e($enquiry->phone); ?>">
                                    <span class="phone-call-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z"/></svg>
                                    </span>
                                    <?php echo e($enquiry->phone); ?>

                                </a>
                            <?php else: ?>
                                <?php echo e($enquiry->phone ?? '—'); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($enquiry->interest): ?>
                                <span class="badge <?php echo e($enquiry->interest === 'offer' ? 'badge-featured' : ''); ?>"><?php echo e($enquiry->interestLabel()); ?></span>
                            <?php endif; ?>
                            <?php if($enquiry->subject): ?>
                                <span class="lead-subject"><?php echo e($enquiry->subject); ?></span>
                            <?php elseif(! $enquiry->interest): ?>
                                —
                            <?php endif; ?>
                        </td>
                        <td class="col-bio"><?php echo e($enquiry->message); ?></td>
                        <td class="text-right nowrap">
                            <?php echo e($enquiry->created_at->timezone($timezone)->format('d M Y, h:i A')); ?>

                            <span class="cell-sub"><?php echo e($enquiry->created_at->diffForHumans()); ?></span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="table-empty">
                            <?php echo e(($from || $to) ? 'No enquiries found for this date range.' : 'No enquiries yet.'); ?>

                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        
        <?php if($enquiries->total() > 0): ?>
            <div class="table-footer">
                <span class="table-count">
                    Showing <?php echo e($enquiries->firstItem()); ?>–<?php echo e($enquiries->lastItem()); ?> of <?php echo e($enquiries->total()); ?> enquiries
                </span>
                <?php echo e($enquiries->links('pagination::default')); ?>

            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>