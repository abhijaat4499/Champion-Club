<?php $__env->startSection('title', 'Contact ChampionClub — Gym in ' . config('gym.address.locality') . ' | Call, WhatsApp or Visit'); ?>
<?php $__env->startSection('description', 'Contact ChampionClub in ' . config('gym.address.locality') . '. Call ' . $gymContact->displayPhone() . ', message us on WhatsApp or visit us at ' . $gymContact->addressLine() . '.'); ?>
<?php $__env->startSection('og_image', 'page-contact'); ?>

<?php $selectedInterest = old('interest', request('interest')); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5045da81eea10cd01496aa62d8386994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5045da81eea10cd01496aa62d8386994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-hero','data' => ['image' => 'page-contact','eyebrow' => 'Contact','title' => 'Let\'s talk training.','crumb' => 'Contact']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'page-contact','eyebrow' => 'Contact','title' => 'Let\'s talk training.','crumb' => 'Contact']); ?>
    Questions about membership, programs, or just want to see the floor first? Reach out, or walk in during opening hours.
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $attributes = $__attributesOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__attributesOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $component = $__componentOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__componentOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>

<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap grid gap-10 lg:grid-cols-12 lg:gap-14">
        <div class="lg:col-span-7" data-reveal>
            <form action="<?php echo e(route('store.contact')); ?>" method="POST" class="contact-form border border-ink-950/10 bg-white p-7 shadow-[0_30px_60px_-40px_rgba(9,9,10,0.45)] sm:p-10" novalidate>
                <?php echo csrf_field(); ?>
                <h2 class="display-md">Send a message</h2>
                <p class="mt-2 mb-8 text-ink-950/60">Share a phone number or an email — we'll get back to you shortly.</p>

                <?php if($errors->any()): ?>
                    <div class="mb-6 border-l-4 border-ember-500 bg-ember-500/10 px-4 py-3 text-sm font-medium text-ember-600" role="alert">Please check the highlighted fields.</div>
                <?php endif; ?>

                <div class="grid gap-5 sm:grid-cols-2">
                    <div class="sm:col-span-2">
                        <label for="name" class="field-label">Name</label>
                        <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" autocomplete="name" required class="field field-light" placeholder="Your full name" <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="phone" class="field-label">Mobile number</label>
                        <input type="tel" id="phone" name="phone" value="<?php echo e(old('phone')); ?>" autocomplete="tel-national" inputmode="numeric" maxlength="10" data-phone class="field field-light" placeholder="10-digit mobile number" <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="email" class="field-label">Email <span class="font-normal text-ink-950/45">(optional)</span></label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" class="field field-light" placeholder="you@example.com" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="sm:col-span-2">
                        <label for="interest" class="field-label">I'm interested in</label>
                        <select id="interest" name="interest" class="field field-light">
                            <option value="" disabled <?php echo e($selectedInterest ? '' : 'selected'); ?>>Select an option</option>
                            <?php $__currentLoopData = \App\Models\Contact::INTERESTS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php echo e($selectedInterest == $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['interest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="sm:col-span-2">
                        <label for="message" class="field-label">Message <span class="font-normal text-ink-950/45">(optional)</span></label>
                        <textarea id="message" name="message" rows="5" class="field field-light resize-y" placeholder="Tell us what you're looking for"><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <button type="submit" class="btn btn-dark mt-7 w-full sm:w-auto">Send message <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></button>
            </form>
        </div>

        <aside class="grid content-start gap-4 lg:col-span-5">
            <?php $__currentLoopData = [
                ['icon' => 'phone', 'title' => 'Call us', 'value' => $gymContact->displayPhone(), 'href' => $gymContact->callUrl(), 'external' => false],
                ['icon' => 'whatsapp', 'title' => 'WhatsApp', 'value' => 'Chat with our team', 'href' => $gymContact->whatsappUrl(), 'external' => true],
                ['icon' => 'mail', 'title' => 'Email', 'value' => $gymContact->email(), 'href' => 'mailto:' . $gymContact->email(), 'external' => false],
                ['icon' => 'pin', 'title' => 'Visit us', 'value' => $gymContact->addressLine(), 'href' => $gymContact->mapsUrl(), 'external' => true],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($c['href']); ?>" <?php if($c['external']): ?> target="_blank" rel="noopener" <?php endif; ?> class="group flex items-center gap-5 border border-ink-950/10 bg-bone-50 p-5 transition hover:border-ink-950 hover:bg-white" data-reveal style="--reveal-delay: <?php echo e($loop->index * 0.06); ?>s">
                    <span class="inline-flex size-12 shrink-0 items-center justify-center rounded-md bg-ink-950 text-xl text-gold-400"><?php echo \App\Support\SiteHtml::icon($c['icon'], ''); ?></span>
                    <span class="min-w-0 flex-1">
                        <span class="block text-xs font-bold tracking-[0.16em] text-ink-950/50 uppercase"><?php echo e($c['title']); ?></span>
                        <span class="mt-0.5 block font-semibold break-words"><?php echo e($c['value']); ?></span>
                    </span>
                    <?php echo \App\Support\SiteHtml::icon('arrow', 'text-ink-950/30 transition group-hover:translate-x-1 group-hover:text-ink-950'); ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="bg-ink-950 p-7 text-white" data-reveal>
                <p class="flex items-center gap-3 text-xs font-bold tracking-[0.16em] text-gold-400 uppercase"><?php echo \App\Support\SiteHtml::icon('clock', 'text-base'); ?> Opening hours</p>
                <ul class="mt-5 space-y-3">
                    <?php $__currentLoopData = $gymContact->hours(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex justify-between gap-4 border-b border-white/10 pb-3 last:border-0 last:pb-0"><span class="text-white/65"><?php echo e($h['days']); ?></span><span class="font-semibold"><?php echo e($h['time']); ?></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </aside>
    </div>
</section>

<section class="bg-bone-100 pb-14 lg:pb-16" aria-label="Map">
    <div class="wrap">
        <div class="aspect-[4/3] overflow-hidden border border-ink-950/10 sm:aspect-[21/9]">
            <?php echo $__env->make('partials.site.map', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\contact-us.blade.php ENDPATH**/ ?>