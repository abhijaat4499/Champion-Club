<?php $__env->startSection('title', 'Our Coaches — Certified Personal Trainers | ChampionClub ' . config('gym.address.locality')); ?>
<?php $__env->startSection('description', 'Meet the ChampionClub coaching team in ' . config('gym.address.locality') . ' — strength, functional training and personal coaches. Book a personal training session.'); ?>
<?php $__env->startSection('og_image', 'page-trainers'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5045da81eea10cd01496aa62d8386994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5045da81eea10cd01496aa62d8386994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-hero','data' => ['image' => 'page-trainers','eyebrow' => 'Coaches','title' => 'Coaches who\'ve done the work.','crumb' => 'Trainers']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'page-trainers','eyebrow' => 'Coaches','title' => 'Coaches who\'ve done the work.','crumb' => 'Trainers']); ?>
    Every coach at ChampionClub has competed, not just certified. Here's who you'll actually be training with.
     <?php $__env->slot('actions', null, []); ?> 
        <a href="<?php echo e(route('gym.contact', ['interest' => 'coaching'])); ?>" class="btn btn-gold">Book a session <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></a>
        <a href="<?php echo e($gymContact->whatsappUrl('Hi, I want to book a personal training session')); ?>" target="_blank" rel="noopener" class="btn btn-ghost"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> WhatsApp us</a>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $attributes = $__attributesOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__attributesOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $component = $__componentOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__componentOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>

<section class="bg-ink-950 pt-10 pb-14 lg:pt-12 lg:pb-16">
    <div class="wrap">
        <?php if($trainers->isEmpty()): ?>
            <div class="mx-auto max-w-xl border border-white/10 bg-ink-900 p-10 text-center">
                <span class="icon-tile"><?php echo \App\Support\SiteHtml::icon('users', ''); ?></span>
                <h2 class="display-md mt-6 text-white">Trainers will be added soon.</h2>
                <a href="<?php echo e(route('gym.contact', ['interest' => 'coaching'])); ?>" class="btn btn-gold mt-8">Ask about coaching</a>
            </div>
        <?php else: ?>
            <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-reveal style="--reveal-delay: <?php echo e(($loop->index % 3) * 0.08); ?>s">
                        <?php echo $__env->make('partials.site.trainer-card', ['trainer' => $trainer, 'bioLimit' => 600], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap">
        <div class="max-w-2xl" data-reveal>
            <p class="eyebrow !text-gold-700">Personal coaching</p>
            <h2 class="display-lg mt-5">Programming built entirely around your goal.</h2>
        </div>
        <ol class="mt-14 grid gap-px overflow-hidden rounded-sm border border-ink-950/10 bg-ink-950/10 md:grid-cols-3">
            <?php $__currentLoopData = [
                ['icon' => 'clipboard', 'title' => 'Custom program design', 'text' => 'One-on-one programming built around your specific goal.'],
                ['icon' => 'dumbbell', 'title' => 'Technique first', 'text' => 'Your coach corrects your form, not just your rep count.'],
                ['icon' => 'calendar', 'title' => 'Weekly check-ins', 'text' => 'Regular check-ins to adjust the plan as you progress.'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="bg-bone-50 p-8 lg:p-10" data-reveal style="--reveal-delay: <?php echo e($loop->index * 0.08); ?>s">
                    <div class="flex items-center justify-between">
                        <span class="inline-flex size-12 items-center justify-center rounded-md bg-ink-950 text-xl text-gold-400"><?php echo \App\Support\SiteHtml::icon($step['icon'], ''); ?></span>
                        <span class="font-display text-5xl font-extrabold text-ink-950/10"><?php echo e(str_pad($loop->iteration, 2, '0', STR_PAD_LEFT)); ?></span>
                    </div>
                    <h3 class="mt-8 font-display text-[1.75rem] leading-tight"><?php echo e($step['title']); ?></h3>
                    <p class="mt-2 leading-relaxed text-ink-950/65"><?php echo e($step['text']); ?></p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>
</section>

<?php echo $__env->make('partials.site.cta-band', ['image' => 'gallery-7', 'title' => 'Train with someone who\'s been there.', 'text' => 'Book a free trial and get matched with the coach who fits your goal.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\trainers.blade.php ENDPATH**/ ?>