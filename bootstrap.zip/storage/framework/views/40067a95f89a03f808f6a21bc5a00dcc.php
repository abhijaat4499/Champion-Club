

<?php $__env->startSection('title', 'New Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrap">
    <form class="auth-card" method="POST" action="<?php echo e(route('admin.password.update')); ?>">
        <?php echo csrf_field(); ?>
        <h1>New Password</h1>
        <p class="auth-sub">Choose a new password (at least 8 characters).</p>

        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert-error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-row">
            <label for="password">New password</label>
            <input type="password" id="password" name="password" required autofocus>
        </div>

        <div class="form-row">
            <label for="password_confirmation">Confirm password</label>
            <input type="password" id="password_confirmation" name="password_confirmation" required>
        </div>

        <button type="submit" class="btn-admin">Update password</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\reset-password.blade.php ENDPATH**/ ?>