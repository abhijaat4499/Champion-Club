<?php if($facility->imageUrl()): ?>
    <img src="<?php echo e($facility->imageUrl()); ?>" style="<?php echo e($facility->imageFocus()); ?>" alt="<?php echo e($facility->title); ?>" width="1200" height="900" loading="lazy" decoding="async" class="object-cover <?php echo e($class); ?>">
<?php else: ?>
    <?php echo \App\Support\SiteHtml::img(\App\Models\Facility::FALLBACK_IMAGE, $class, false, $facility->title); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/partials/site/facility-image.blade.php ENDPATH**/ ?>