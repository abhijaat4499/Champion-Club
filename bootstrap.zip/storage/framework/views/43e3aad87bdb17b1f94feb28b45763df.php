<?php $__env->startSection('title', 'Gym Membership Plans & Prices — No Lock-in | ChampionClub ' . config('gym.address.locality')); ?>
<?php $__env->startSection('description', 'Compare ChampionClub membership plans and prices. No joining fee, no lock-in contracts, free freeze every quarter. Book a free trial in ' . config('gym.address.locality') . '.'); ?>
<?php $__env->startSection('og_image', 'page-membership'); ?>

<?php
    $faqs = [
        ['q' => 'Is there a joining fee?', 'a' => 'No hidden joining fee. The price you see on each plan is exactly what you pay, billed monthly.'],
        ['q' => 'Can I freeze my membership?', 'a' => 'Yes — every plan includes one free freeze per quarter, for up to two weeks, for travel or medical reasons.'],
        ['q' => 'Can I switch plans later?', 'a' => 'Absolutely. Upgrade or downgrade any time from the front desk — the change applies from your next billing cycle.'],
        ['q' => 'What if I want to cancel?', 'a' => "There's no lock-in contract on any plan. Cancel any time, no cancellation fee."],
        ['q' => 'Do you offer student or corporate discounts?', 'a' => 'Yes — ask the front desk about current student and corporate group offers.'],
    ];
?>

<?php $__env->startPush('schema'); ?>
<script type="application/ld+json"><?php echo json_encode([
    '<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>' => 'https://schema.org',
    '@type' => 'FAQPage',
    'mainEntity' => collect($faqs)->map(fn ($f) => ['@type' => 'Question', 'name' => $f['q'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['a']]])->all(),
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5045da81eea10cd01496aa62d8386994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5045da81eea10cd01496aa62d8386994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-hero','data' => ['image' => 'page-membership','eyebrow' => 'Membership','title' => 'Membership that matches your intensity.','crumb' => 'Membership']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'page-membership','eyebrow' => 'Membership','title' => 'Membership that matches your intensity.','crumb' => 'Membership']); ?>
    No lock-in contracts. Pause or cancel any time. Pick the plan that fits where you are right now — you can always change it later.
     <?php $__env->slot('actions', null, []); ?> 
        <a href="#plans" class="btn btn-gold">See plans <?php echo \App\Support\SiteHtml::icon('down', ''); ?></a>
        <a href="<?php echo e(route('gym.trial')); ?>" class="btn btn-ghost">Try it free first</a>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $attributes = $__attributesOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__attributesOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $component = $__componentOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__componentOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>


<section id="plans" class="scroll-mt-24 overflow-hidden bg-ink-950 pt-10 pb-14 lg:pt-12 lg:pb-16">
    <div class="wrap">
        <?php if($plans->isNotEmpty()): ?>
            <?php $featuredIndex = max(0, $plans->search(fn ($p) => $p->is_featured)); ?>
            <div data-carousel="plans" data-initial="<?php echo e($featuredIndex); ?>">
                <div class="plans-slider swiper !overflow-visible !pt-6" style="--initial: <?php echo e($featuredIndex); ?>" data-reveal>
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide !h-auto px-2 lg:px-0 <?php echo e($loop->index === $featuredIndex ? 'swiper-slide-active' : ''); ?>">
                                <?php echo $__env->make('partials.site.plan-card', ['plan' => $plan], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="carousel-dots mt-10 justify-center text-white lg:hidden" data-dots></div>
            </div>
        <?php else: ?>
            <p class="text-center text-white/60">Plans will be published soon. <a href="<?php echo e(route('gym.contact', ['interest' => 'membership'])); ?>" class="text-gold-400 underline">Ask us for current prices.</a></p>
        <?php endif; ?>

        <div class="mt-16 grid gap-px overflow-hidden rounded-sm border border-white/10 bg-white/10 sm:grid-cols-3" data-reveal>
            <?php $__currentLoopData = [
                ['icon' => 'dumbbell', 'title' => 'Full gym floor access', 'text' => 'Included with every plan.'],
                ['icon' => 'shower', 'title' => 'Lockers & showers', 'text' => 'Included with every plan.'],
                ['icon' => 'clipboard', 'title' => 'Induction session', 'text' => 'One coached induction to get you started.'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center gap-4 bg-ink-900 p-6">
                    <span class="icon-ring"><?php echo \App\Support\SiteHtml::icon($item['icon'], 'text-lg'); ?></span>
                    <div>
                        <p class="font-bold text-white"><?php echo e($item['title']); ?></p>
                        <p class="text-sm text-white/55"><?php echo e($item['text']); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-12 flex flex-col items-center gap-5 sm:flex-row sm:justify-center" data-reveal>
            <a href="<?php echo e($gymContact->whatsappUrl()); ?>" target="_blank" rel="noopener" class="btn btn-whatsapp"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> Get your membership</a>
            <a href="<?php echo e($gymContact->callUrl()); ?>" class="btn btn-ghost"><?php echo \App\Support\SiteHtml::icon('phone', ''); ?> Call <?php echo e($gymContact->displayPhone()); ?></a>
        </div>
    </div>
</section>


<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap grid gap-12 lg:grid-cols-12">
        <div class="lg:col-span-5" data-reveal>
            <p class="eyebrow !text-gold-700">FAQs</p>
            <h2 class="display-lg mt-5">Membership questions, answered.</h2>
            <p class="lead mt-5 text-ink-950/65">Still deciding? Here's what members ask most before signing up.</p>
            <a href="<?php echo e($gymContact->whatsappUrl('Hi, I have a question about membership')); ?>" target="_blank" rel="noopener" class="btn btn-dark mt-8"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> Ask us anything</a>
        </div>
        <div class="lg:col-span-7">
            <div class="divide-y divide-ink-950/10 border-y border-ink-950/10">
                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <details class="accordion group py-2" data-reveal <?php if($loop->first): ?> open <?php endif; ?>>
                        <summary class="py-5 font-display text-2xl leading-tight font-bold">
                            <?php echo e($faq['q']); ?>

                            <span class="inline-flex size-10 shrink-0 items-center justify-center rounded-full border border-ink-950/15 text-lg transition group-open:border-ink-950 group-open:bg-ink-950 group-open:text-gold-400"><?php echo \App\Support\SiteHtml::icon('down', ''); ?></span>
                        </summary>
                        <p class="accordion-body max-w-2xl pb-6 text-[1.02rem] leading-relaxed text-ink-950/70"><?php echo e($faq['a']); ?></p>
                    </details>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('partials.site.cta-band', ['image' => 'gallery-4', 'title' => 'Still not sure which plan fits?', 'text' => "Walk in, meet the coaches, and we'll help you pick — no pressure, no sales pitch."], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/membership.blade.php ENDPATH**/ ?>