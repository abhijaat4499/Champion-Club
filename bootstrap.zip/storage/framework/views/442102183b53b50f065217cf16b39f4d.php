<?php if(isset($photo['url'])): ?>
    <img src="<?php echo e($photo['url']); ?>" alt="<?php echo e($alt); ?>" width="900" height="1200" loading="lazy" decoding="async" class="object-cover <?php echo e($class); ?>">
<?php else: ?>
    <?php echo \App\Support\SiteHtml::img($photo['site'], $class, false, $alt); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\partials\site\about-photo.blade.php ENDPATH**/ ?>