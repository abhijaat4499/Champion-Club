<?php $__env->startSection('title', 'Services — Coached Training | ChampionClub ' . config('gym.address.locality')); ?>
<?php $__env->startSection('description', 'Explore coached services at ChampionClub ' . config('gym.address.locality') . ($services->isNotEmpty() ? ': ' . $services->pluck('title')->implode(', ') . '.' : '.')); ?>
<?php $__env->startSection('og_image', 'page-programs'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5045da81eea10cd01496aa62d8386994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5045da81eea10cd01496aa62d8386994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-hero','data' => ['image' => 'page-programs','eyebrow' => 'Services','title' => 'Coached services for every goal.','crumb' => 'Services']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'page-programs','eyebrow' => 'Services','title' => 'Coached services for every goal.','crumb' => 'Services']); ?>
    Every service is coached, not just supervised. Pick one, or mix a few once you know what you like.
     <?php $__env->slot('actions', null, []); ?> 
        <a href="<?php echo e(route('gym.trial')); ?>" class="btn btn-gold">Book a free trial <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></a>
        <a href="<?php echo e($gymContact->whatsappUrl('Hi, I want help choosing a service')); ?>" target="_blank" rel="noopener" class="btn btn-ghost"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> Help me choose</a>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $attributes = $__attributesOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__attributesOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $component = $__componentOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__componentOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>

<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap">
        <?php if($services->isEmpty()): ?>
            <div class="mx-auto max-w-xl border border-white/10 bg-ink-900 p-10 text-center">
                <span class="icon-tile"><?php echo \App\Support\SiteHtml::icon('dumbbell', ''); ?></span>
                <h2 class="display-md mt-6 text-white">Services will be added soon.</h2>
                <a href="<?php echo e(route('gym.contact')); ?>" class="btn btn-gold mt-8">Ask us about training</a>
            </div>
        <?php else: ?>
            <div class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-reveal style="--reveal-delay: <?php echo e(($loop->index % 3) * 0.08); ?>s">
                        <?php echo $__env->make('partials.site.service-card', ['service' => $service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php echo $__env->make('partials.site.cta-band', ['image' => 'gallery-6', 'title' => 'Not sure which service fits?', 'text' => 'Book a free trial and a coach will help you pick the right one.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/services.blade.php ENDPATH**/ ?>