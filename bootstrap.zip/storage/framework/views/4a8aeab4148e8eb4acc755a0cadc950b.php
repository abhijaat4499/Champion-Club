<div class="map-embed relative size-full" data-map="<?php echo e($gymContact->mapEmbedUrl()); ?>">
    <div class="map-placeholder absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[radial-gradient(circle_at_50%_45%,rgba(212,165,55,0.18),transparent_60%)] p-6 text-center text-ink-950">
        <span class="inline-flex size-14 items-center justify-center rounded-full bg-ink-950 text-2xl text-gold-400"><?php echo \App\Support\SiteHtml::icon('pin', ''); ?></span>
        <p class="max-w-xs text-sm font-semibold"><?php echo e($gymContact->addressLine()); ?></p>
        <a href="<?php echo e($gymContact->mapsUrl()); ?>" target="_blank" rel="noopener" class="link-arrow text-sm font-bold text-gold-700">Open in Google Maps <?php echo \App\Support\SiteHtml::icon('external', ''); ?></a>
    </div>
    <noscript>
        <iframe src="<?php echo e($gymContact->mapEmbedUrl()); ?>" title="Map showing ChampionClub location" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="absolute inset-0 size-full border-0 grayscale-[35%]"></iframe>
    </noscript>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/partials/site/map.blade.php ENDPATH**/ ?>