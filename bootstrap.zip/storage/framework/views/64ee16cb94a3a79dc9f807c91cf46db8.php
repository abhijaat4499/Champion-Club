<?php
    $video = $video ?? null;
?>

<div class="form-row span-2">
    <label for="youtube_url">YouTube video link</label>
    <input type="url" id="youtube_url" name="youtube_url" value="<?php echo e(old('youtube_url', $video ? $video->watchUrl() : '')); ?>" placeholder="https://www.youtube.com/watch?v=..." required>
    <small>Paste the link of a video, a YouTube Short or a youtu.be link.</small>
    <?php $__errorArgs = ['youtube_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['youtube_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="title">Video title</label>
    <input type="text" id="title" name="title" value="<?php echo e(old('title', $video->title ?? '')); ?>" placeholder="e.g. Lost 12 kg in 4 months" maxlength="120" required>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="name">Member name <small>(optional)</small></label>
    <input type="text" id="name" name="name" value="<?php echo e(old('name', $video->name ?? '')); ?>" maxlength="80">
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="display_order">Display order</label>
    <input type="number" id="display_order" name="display_order" min="0" value="<?php echo e(old('display_order', $video->display_order ?? 0)); ?>" required>
    <?php $__errorArgs = ['display_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php if($video): ?>
    <div class="form-row">
        <label>Preview</label>
        <img src="<?php echo e($video->thumbnailUrl()); ?>" alt="<?php echo e($video->title); ?>" class="service-thumb-preview">
    </div>
<?php endif; ?>

<div class="checkbox-field">
    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : ($video->is_active ?? true)) ? 'checked' : ''); ?>>
    <label for="is_active">Show on website</label>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\videos\_form.blade.php ENDPATH**/ ?>