<a href="<?php echo e(route('gym.service', $service)); ?>" class="zoom-media group flex h-full flex-col overflow-hidden rounded-md border border-white/10 bg-ink-850 transition hover:border-gold-500/60">
    <div class="relative aspect-[4/3] overflow-hidden bg-ink-800">
        <?php if($service->imageUrl()): ?>
            <img src="<?php echo e($service->imageUrl()); ?>" style="<?php echo e($service->imageFocus()); ?>" alt="<?php echo e($service->title); ?>" width="640" height="480" loading="lazy" decoding="async" class="absolute inset-0 size-full object-cover">
        <?php else: ?>
            <?php echo \App\Support\SiteHtml::img(\App\Models\Service::FALLBACK_IMAGE, 'absolute inset-0 size-full', false, $service->title); ?>
        <?php endif; ?>
        <div class="absolute inset-0 bg-gradient-to-t from-ink-850 via-transparent to-transparent"></div>
        <span class="absolute bottom-4 left-5 inline-flex size-12 items-center justify-center rounded-md bg-gold-500 text-xl text-ink-950"><?php echo \App\Support\SiteHtml::icon($service->iconName(), ''); ?></span>
    </div>
    <div class="flex flex-1 flex-col p-6">
        <h3 class="font-display text-[1.75rem] leading-tight text-white"><?php echo e($service->title); ?></h3>
        <p class="mt-3 flex-1 text-[0.95rem] leading-relaxed text-white/65"><?php echo e($service->summary); ?></p>
        <span class="link-arrow mt-6 self-start">View service <?php echo \App\Support\SiteHtml::icon('arrow', 'transition-transform duration-300 group-hover:translate-x-1'); ?></span>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/partials/site/service-card.blade.php ENDPATH**/ ?>