

<?php $__env->startSection('title', 'Forgot Password'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrap">
    <form data-sends-code class="auth-card" method="POST" action="<?php echo e(route('admin.password.email')); ?>">
        <?php echo csrf_field(); ?>
        <h1>Forgot Password</h1>
        <p class="auth-sub">Enter your admin email and we'll send you a verification code.</p>

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert-error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-row">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        </div>

        <button type="submit" class="btn-admin">Send code</button>

        <p class="auth-link"><a href="<?php echo e(route('admin.login')); ?>">Back to login</a></p>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\forgot-password.blade.php ENDPATH**/ ?>