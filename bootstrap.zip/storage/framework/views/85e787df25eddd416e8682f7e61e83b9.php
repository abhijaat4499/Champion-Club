<?php $__env->startSection('title', 'Edit Photo'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Edit photo','icon' => 'gallery']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit photo','icon' => 'gallery']); ?>
        <a href="<?php echo e(route('admin.gallery.index')); ?>" class="btn-logout">&larr; Back to gallery</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.gallery.update', $photo)); ?>" class="plan-form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-row">
            <label>Current photo</label>
            <img src="<?php echo e($photo->url()); ?>" alt="<?php echo e($photo->alt); ?>" class="gallery-edit-preview">
        </div>

        <div class="form-row">
            <label for="image">Replace photo <small>(optional)</small></label>
            <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp">
            <small><?php echo e(\App\Support\ImageUpload::HINT); ?></small>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-row">
            <label for="alt">Alt text</label>
            <input type="text" id="alt" name="alt" value="<?php echo e(old('alt', $photo->alt)); ?>" maxlength="160" required>
            <small>Describe what is in the photo, e.g. "Treadmills beside large windows".</small>
            <?php $__errorArgs = ['alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-row">
            <label for="caption">Caption <small>(optional)</small></label>
            <input type="text" id="caption" name="caption" value="<?php echo e(old('caption', $photo->caption)); ?>" maxlength="160">
            <?php $__errorArgs = ['caption'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="checkbox-field">
            <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : $photo->is_active) ? 'checked' : ''); ?>>
            <label for="is_active">Show on website</label>
        </div>

        <button type="submit" class="btn-admin">Update Photo</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\gallery\edit.blade.php ENDPATH**/ ?>