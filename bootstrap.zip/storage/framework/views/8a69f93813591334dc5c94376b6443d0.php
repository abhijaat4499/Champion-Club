<?php $__env->startSection('title', 'Facilities'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Facilities','icon' => 'facilities']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Facilities','icon' => 'facilities']); ?>
        <a href="<?php echo e(route('gym.facilities')); ?>" class="btn-logout" target="_blank" rel="noopener">View on website</a>
        <a href="<?php echo e(route('admin.facilities.create')); ?>" class="btn-admin-small">+ Add Facility</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <p class="settings-note">Shown on the Facilities page. The first five also appear on the home page.</p>

    <table class="admin-table">
        <thead>
            <tr>
                <th class="col-order">Order</th>
                <th>Facility</th>
                <th>Description</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="col-order"><span class="order-chip"><?php echo e($facility->display_order); ?></span></td>
                    <td>
                        <div class="person-cell">
                            <?php if($facility->image): ?>
                                <img src="<?php echo e($facility->imageUrl()); ?>" alt="<?php echo e($facility->title); ?>" class="service-thumb" style="<?php echo e($facility->imageFocus()); ?>">
                            <?php else: ?>
                                <span class="service-thumb service-thumb-empty"><?php echo e(mb_strtoupper(mb_substr($facility->title, 0, 1))); ?></span>
                            <?php endif; ?>
                            <span class="person-name"><?php echo e($facility->title); ?></span>
                        </div>
                    </td>
                    <td class="col-bio"><?php echo e(\Illuminate\Support\Str::limit($facility->text, 90)); ?></td>
                    <td>
                        <span class="status-chip status-<?php echo e($facility->is_active ? 'live' : 'hidden'); ?>"><?php echo e($facility->is_active ? 'Live' : 'Hidden'); ?></span>
                    </td>
                    <td class="text-right">
                        <div class="row-actions">
                            <a href="<?php echo e(route('admin.facilities.edit', $facility)); ?>" class="btn-edit">Edit</a>

                            <form action="<?php echo e(route('admin.facilities.destroy', $facility)); ?>" method="POST"
                                  onsubmit="return confirm('Delete this facility?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="table-empty">No facilities yet. Add your first facility to show it on the website.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/facilities/index.blade.php ENDPATH**/ ?>