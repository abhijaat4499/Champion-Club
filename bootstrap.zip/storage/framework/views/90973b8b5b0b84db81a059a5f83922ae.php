<?php
    $siteName = config('gym.name');
    $pageTitle = trim($__env->yieldContent('title', $siteName . ' — Strength & Conditioning Gym in ' . config('gym.address.locality')));
    $pageDescription = trim($__env->yieldContent('description', 'ChampionClub is a strength and conditioning gym in ' . config('gym.address.locality') . ' with certified coaches, competition-grade equipment and no lock-in contracts. Book a free trial session.'));
    $canonical = (request()->is('/') || request()->routeIs('gym.home')) ? url('/') : url()->current();
    $ogImage = asset(config('site-images.' . trim($__env->yieldContent('og_image', 'hero-strength')) . '.src', 'images/site/hero-strength.webp'));

    $nav = [
        ['route' => 'gym.about', 'label' => 'About'],
        ['route' => 'gym.services', 'label' => 'Services', 'match' => ['gym.services', 'gym.service', 'gym.book.service']],
        ['route' => 'gym.trainers', 'label' => 'Trainers', 'match' => ['gym.trainers', 'gym.book.trainer']],
        ['route' => 'gym.membership', 'label' => 'Membership', 'match' => ['gym.membership', 'gym.book.plan']],
        ['route' => 'gym.offers', 'label' => 'Offers', 'match' => ['gym.offers', 'gym.book.offer']],
        ['route' => 'gym.gallery', 'label' => 'Gallery'],
        ['route' => 'gym.contact', 'label' => 'Contact'],
    ];

    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'ExerciseGym',
        'name' => $siteName,
        'url' => url('/'),
        'image' => asset(config('site-images.hero-facility.src')),
        'logo' => asset('images/logo.jpg'),
        'telephone' => $gymContact->schemaPhone(),
        'hasMap' => $gymContact->mapsUrl(),
        'email' => $gymContact->email(),
        'address' => [
            '@type' => 'PostalAddress',
            'streetAddress' => config('gym.address.street'),
            'addressLocality' => config('gym.address.locality'),
            'addressRegion' => config('gym.address.region'),
            'addressCountry' => config('gym.address.country'),
        ],
        'openingHours' => collect(config('gym.hours'))->pluck('schema')->all(),
        'sameAs' => array_values(array_filter(config('gym.social'))),
    ];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo e($pageTitle); ?></title>
<meta name="description" content="<?php echo e($pageDescription); ?>">
<link rel="canonical" href="<?php echo e($canonical); ?>">
<meta name="theme-color" content="#09090a">

<meta property="og:type" content="website">
<meta property="og:site_name" content="<?php echo e($siteName); ?>">
<meta property="og:title" content="<?php echo e($pageTitle); ?>">
<meta property="og:description" content="<?php echo e($pageDescription); ?>">
<meta property="og:url" content="<?php echo e($canonical); ?>">
<meta property="og:image" content="<?php echo e($ogImage); ?>">
<meta name="twitter:card" content="summary_large_image">

<?php echo $__env->make('partials.fonts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->yieldPushContent('preload'); ?>

<script>
(function (d) {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    d.classList.add('js-motion');
    setTimeout(function () { if (!window.__appReady) d.classList.remove('js-motion'); }, 4000);
})(document.documentElement);
</script>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

<script type="application/ld+json"><?php echo json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?></script>
<?php echo $__env->yieldPushContent('schema'); ?>
</head>
<body class="<?php echo $__env->yieldContent('body_class'); ?> pb-16 lg:pb-0">

<a href="#main" class="sr-only z-[100] rounded bg-gold-500 px-4 py-2 font-bold text-ink-950 focus:not-sr-only focus:fixed focus:top-4 focus:left-4">Skip to content</a>


<header class="site-header fixed inset-x-0 top-0 z-50" data-header>
    <div class="hidden h-10 border-b border-white/10 bg-ink-950 text-[0.8rem] text-white/65 lg:block">
        <div class="wrap flex h-full items-center justify-between">
            <p class="flex items-center gap-2">
                <?php echo \App\Support\SiteHtml::icon('clock', 'text-gold-500'); ?>
                <?php $__currentLoopData = $gymContact->hours(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($h['days']); ?> <?php echo e($h['time']); ?></span><?php if(!$loop->last): ?><span class="text-white/25">·</span><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <div class="flex items-center gap-6">
                <a href="<?php echo e($gymContact->mapsUrl()); ?>" target="_blank" rel="noopener" class="flex items-center gap-2 transition hover:text-white">
                    <?php echo \App\Support\SiteHtml::icon('pin', 'text-gold-500'); ?> <?php echo e(config('gym.address.locality')); ?>, <?php echo e(config('gym.address.region')); ?>

                </a>
                <a href="<?php echo e($gymContact->callUrl()); ?>" class="flex items-center gap-2 font-semibold text-white transition hover:text-gold-400">
                    <?php echo \App\Support\SiteHtml::icon('phone', 'text-gold-500'); ?> <?php echo e($gymContact->displayPhone()); ?>

                </a>
            </div>
        </div>
    </div>

    <div class="header-bar border-b border-transparent bg-gradient-to-b from-ink-950/80 to-transparent py-4 lg:py-5">
        <div class="wrap flex items-center justify-between gap-6">
            <a href="<?php echo e(url('/')); ?>" class="flex shrink-0 items-center gap-3" aria-label="<?php echo e($siteName); ?> home">
                <img src="<?php echo e(asset('images/logo-sm.webp')); ?>" alt="" width="44" height="44" class="size-10 rounded-full ring-1 ring-gold-500/60 lg:size-11">
                <span class="font-display text-[1.6rem] leading-none font-extrabold tracking-wide text-white uppercase">Champion<span class="text-gold-500">Club</span></span>
            </a>

            <nav aria-label="Primary" class="hidden xl:block">
                <ul class="flex items-center gap-7">
                    <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item['route'] === 'gym.services' && $navServices->isNotEmpty()): ?>
                            <li class="nav-drop">
                                <a href="<?php echo e(route($item['route'])); ?>" class="nav-link inline-flex items-center gap-1.5" aria-haspopup="true" <?php if(request()->routeIs($item['match'])): ?> aria-current="page" <?php endif; ?>>
                                    <?php echo e($item['label']); ?> <?php echo \App\Support\SiteHtml::icon('down', 'nav-drop-caret text-[0.55rem]'); ?>
                                </a>
                                <div class="nav-drop-panel">
                                    <ul class="nav-drop-menu">
                                        <?php $__currentLoopData = $navServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('gym.service', $navService)); ?>" class="nav-drop-link" <?php if(request()->routeIs('gym.service') && request()->route('service')?->is($navService)): ?> aria-current="page" <?php endif; ?>>
                                                    <span class="nav-drop-icon"><?php echo \App\Support\SiteHtml::icon($navService->iconName(), ''); ?></span>
                                                    <?php echo e($navService->title); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <a href="<?php echo e(route('gym.services')); ?>" class="nav-drop-all">All services <?php echo \App\Support\SiteHtml::icon('arrow', ''); ?></a>
                                </div>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="<?php echo e(route($item['route'])); ?>" class="nav-link" <?php if(request()->routeIs($item['match'] ?? $item['route'])): ?> aria-current="page" <?php endif; ?>><?php echo e($item['label']); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </nav>

            <div class="flex items-center gap-2.5">
                <a href="<?php echo e($gymContact->whatsappUrl()); ?>" target="_blank" rel="noopener" class="nav-whatsapp btn btn-whatsapp btn-sm max-sm:size-11 max-sm:p-0" aria-label="WhatsApp us">
                    <?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?><span class="max-sm:hidden">WhatsApp us</span>
                </a>
                <a href="<?php echo e(route('gym.trial')); ?>" class="btn btn-gold btn-sm max-sm:hidden">Free trial</a>
                <button type="button" class="inline-flex size-11 items-center justify-center rounded-[4px] border border-white/20 text-xl text-white transition hover:border-gold-500 hover:text-gold-400 xl:hidden"
                        data-menu-open aria-controls="mobileMenu" aria-expanded="false" aria-label="Open menu">
                    <?php echo \App\Support\SiteHtml::icon('menu', ''); ?>
                </button>
            </div>
        </div>
    </div>
</header>


<div id="mobileMenu" class="mobile-menu fixed inset-0 z-[60] flex flex-col overflow-y-auto bg-ink-950" data-menu hidden role="dialog" aria-modal="true" aria-label="Menu">
    <div class="wrap flex items-center justify-between py-4">
        <span class="font-display text-[1.6rem] font-extrabold tracking-wide text-white uppercase">Champion<span class="text-gold-500">Club</span></span>
        <button type="button" class="inline-flex size-11 items-center justify-center rounded-[4px] border border-white/20 text-xl text-white" data-menu-close aria-label="Close menu">
            <?php echo \App\Support\SiteHtml::icon('close', ''); ?>
        </button>
    </div>

    <nav aria-label="Mobile" class="wrap flex-1 py-6">
        <ul class="divide-y divide-white/10 border-y border-white/10">
            <li class="menu-item" style="--i: 0">
                <a href="<?php echo e(url('/')); ?>" class="flex items-baseline gap-4 py-4 font-display text-4xl font-bold text-white">
                    <span class="font-sans text-xs font-bold tracking-widest text-gold-500">00</span> Home
                </a>
            </li>
            <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="menu-item" style="--i: <?php echo e($loop->iteration); ?>">
                    <a href="<?php echo e(route($item['route'])); ?>" class="flex items-baseline gap-4 py-4 font-display text-4xl font-bold <?php echo e(request()->routeIs($item['match'] ?? $item['route']) ? 'text-gold-400' : 'text-white'); ?>">
                        <span class="font-sans text-xs font-bold tracking-widest text-gold-500"><?php echo e(str_pad($loop->iteration, 2, '0', STR_PAD_LEFT)); ?></span> <?php echo e($item['label']); ?>

                    </a>
                    <?php if($item['route'] === 'gym.services' && $navServices->isNotEmpty()): ?>
                        <ul class="grid gap-1 pb-4 pl-9">
                            <?php $__currentLoopData = $navServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('gym.service', $navService)); ?>" class="flex items-center gap-3 py-1.5 text-[0.95rem] font-semibold text-white/70 transition hover:text-gold-400">
                                        <?php echo \App\Support\SiteHtml::icon($navService->iconName(), 'text-gold-500'); ?> <?php echo e($navService->title); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>

    <div class="wrap grid gap-3 pb-8">
        <a href="<?php echo e(route('gym.trial')); ?>" class="btn btn-gold w-full">Book a free trial <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></a>
        <div class="grid grid-cols-2 gap-3">
            <a href="<?php echo e($gymContact->callUrl()); ?>" class="btn btn-ghost w-full"><?php echo \App\Support\SiteHtml::icon('phone', ''); ?> Call us</a>
            <a href="<?php echo e($gymContact->whatsappUrl()); ?>" target="_blank" rel="noopener" class="btn btn-whatsapp w-full"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> WhatsApp</a>
        </div>
    </div>
</div>

<main id="main">
    <?php echo $__env->yieldContent('content'); ?>
</main>


<footer class="relative border-t border-white/10 bg-ink-950 pt-20 pb-10 text-white/65">
    <div class="wrap grid gap-x-10 gap-y-12 sm:grid-cols-2 lg:grid-cols-[minmax(0,22rem)_auto_auto_auto] lg:justify-between lg:gap-x-12">
        <div>
            <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-3">
                <img src="<?php echo e(asset('images/logo-sm.webp')); ?>" alt="" width="48" height="48" loading="lazy" class="size-12 rounded-full ring-1 ring-gold-500/60">
                <span class="font-display text-3xl font-extrabold tracking-wide text-white uppercase">Champion<span class="text-gold-500">Club</span></span>
            </a>
            <p class="mt-5 max-w-sm leading-relaxed">A strength and conditioning gym for people training for their next personal best. Real coaching, real equipment, real results.</p>

            <div class="mt-7 flex flex-wrap gap-3">
                <a href="<?php echo e($gymContact->whatsappUrl()); ?>" target="_blank" rel="noopener" class="footer-cta-wa btn btn-whatsapp btn-sm"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> WhatsApp us</a>
                <a href="<?php echo e($gymContact->callUrl()); ?>" class="footer-cta-call btn btn-ghost btn-sm"><?php echo \App\Support\SiteHtml::icon('phone', ''); ?> Call us</a>
            </div>

            <?php if(array_filter(config('gym.social'))): ?>
                <div class="mt-7 flex gap-3">
                    <?php $__currentLoopData = array_filter(config('gym.social')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($url); ?>" target="_blank" rel="noopener" class="inline-flex size-11 items-center justify-center rounded-full border border-white/15 text-lg text-white transition hover:border-gold-500 hover:text-gold-400" aria-label="<?php echo e($siteName); ?> on <?php echo e(ucfirst($network)); ?>">
                            <?php echo \App\Support\SiteHtml::icon($network, ''); ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <div>
            <h2 class="font-sans text-xs font-bold tracking-[0.2em] text-white uppercase">Explore</h2>
            <ul class="mt-5 space-y-3">
                <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item['route'] === 'gym.contact') continue; ?>
                    <li><a href="<?php echo e(route($item['route'])); ?>" class="transition hover:text-gold-400"><?php echo e($item['label']); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div>
            <h2 class="font-sans text-xs font-bold tracking-[0.2em] text-white uppercase">Visit</h2>
            <ul class="mt-5 space-y-4">
                <li class="flex items-start gap-3">
                    <span class="icon-ring size-9 shrink-0 text-sm"><?php echo \App\Support\SiteHtml::icon('pin', ''); ?></span>
                    <div>
                        <address class="leading-relaxed not-italic"><?php echo e(config('gym.address.street')); ?><br><?php echo e(config('gym.address.locality')); ?>, <?php echo e(config('gym.address.region')); ?></address>
                        <a href="<?php echo e($gymContact->mapsUrl()); ?>" target="_blank" rel="noopener" class="link-arrow mt-1 text-sm">Get directions <?php echo \App\Support\SiteHtml::icon('external', ''); ?></a>
                    </div>
                </li>
                <?php $__currentLoopData = $gymContact->hours(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex items-center gap-3">
                        <span class="icon-ring size-9 shrink-0 text-sm"><?php echo \App\Support\SiteHtml::icon('clock', ''); ?></span>
                        <div class="leading-tight">
                            <span class="block text-xs font-semibold tracking-wider text-white/45 uppercase"><?php echo e($h['days']); ?></span>
                            <span class="mt-1 block text-white"><?php echo e($h['time']); ?></span>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div>
            <h2 class="font-sans text-xs font-bold tracking-[0.2em] text-white uppercase">Contact</h2>
            <ul class="mt-5 space-y-4">
                <li><a href="<?php echo e($gymContact->callUrl()); ?>" class="flex items-center gap-3 transition hover:text-gold-400"><span class="icon-ring size-9 text-sm"><?php echo \App\Support\SiteHtml::icon('phone', ''); ?></span><?php echo e($gymContact->displayPhone()); ?></a></li>
                <li><a href="mailto:<?php echo e($gymContact->email()); ?>" class="flex items-center gap-3 transition hover:text-gold-400"><span class="icon-ring size-9 text-sm"><?php echo \App\Support\SiteHtml::icon('mail', ''); ?></span><?php echo e($gymContact->email()); ?></a></li>
                <li><a href="<?php echo e($gymContact->whatsappUrl()); ?>" target="_blank" rel="noopener" class="flex items-center gap-3 transition hover:text-gold-400"><span class="icon-ring size-9 text-sm"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?></span>Chat on WhatsApp</a></li>
            </ul>
        </div>
    </div>

    <div class="wrap mt-16 flex flex-col gap-3 border-t border-white/10 pt-8 text-xs text-white/40 sm:flex-row sm:items-center sm:justify-between">
        <p>© <span data-year><?php echo e(date('Y')); ?></span> <?php echo e($siteName); ?>. All rights reserved.</p>
    </div>
</footer>


<div class="fixed inset-x-0 bottom-0 z-40 grid grid-cols-3 border-t border-white/10 bg-ink-950/95 backdrop-blur-xl lg:hidden">
    <a href="<?php echo e($gymContact->callUrl()); ?>" class="flex flex-col items-center gap-1 py-2.5 text-[0.72rem] font-semibold text-white"><?php echo \App\Support\SiteHtml::icon('phone', 'text-lg text-gold-400'); ?> Call</a>
    <a href="<?php echo e($gymContact->whatsappUrl()); ?>" target="_blank" rel="noopener" class="flex flex-col items-center gap-1 border-x border-white/10 py-2.5 text-[0.72rem] font-semibold text-white"><?php echo \App\Support\SiteHtml::icon('whatsapp', 'text-lg text-[#25d366]'); ?> WhatsApp</a>
    <a href="<?php echo e(route('gym.trial')); ?>" class="flex flex-col items-center gap-1 bg-gold-500 py-2.5 text-[0.72rem] font-bold text-ink-950"><?php echo \App\Support\SiteHtml::icon('bolt', 'text-lg'); ?> Free trial</a>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/layouts/app.blade.php ENDPATH**/ ?>