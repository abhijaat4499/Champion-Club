<?php $__env->startSection('title', 'About & Contact'); ?>

<?php
    $hours = old('hours', config('gym.hours'));
    $highlights = old('highlights', config('gym.highlights'));
?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'About & Contact','icon' => 'about']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'About & Contact','icon' => 'about']); ?>
        <a href="<?php echo e(route('gym.about')); ?>" class="btn-logout" target="_blank" rel="noopener">View on website</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert-error settings-errors">
            <strong>Please fix these and save again:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.site.update')); ?>" class="site-form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <section class="settings-card">
            <h2>Contact details</h2>
            <p class="settings-note">Used in the header, footer, call and WhatsApp buttons across the website.</p>

            <div class="form-row">
                <label for="phone">Phone number</label>
                <input type="tel" id="phone" name="phone" value="<?php echo e(old('phone', preg_replace('/\D/', '', config('gym.phone')))); ?>" inputmode="numeric" maxlength="10" required>
                <small>10-digit mobile number, without +91 or 0.</small>
            </div>

            <div class="form-row">
                <label for="whatsapp">WhatsApp number</label>
                <input type="tel" id="whatsapp" name="whatsapp" value="<?php echo e(old('whatsapp', preg_replace('/\D/', '', config('gym.whatsapp')))); ?>" inputmode="numeric" maxlength="10" required>
                <small>10-digit number that receives WhatsApp messages.</small>
            </div>

            <div class="form-row">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email', config('gym.email'))); ?>" required>
            </div>

            <div class="form-row">
                <label for="whatsapp_message">Default WhatsApp message</label>
                <input type="text" id="whatsapp_message" name="whatsapp_message" value="<?php echo e(old('whatsapp_message', config('gym.whatsapp_message'))); ?>" maxlength="200" required>
            </div>
        </section>

        
        <section class="settings-card">
            <h2>Address</h2>
            <p class="settings-note">The Google map and "Get directions" links use this address.</p>

            <div class="form-row span-2">
                <label for="street">Street address</label>
                <input type="text" id="street" name="address[street]" value="<?php echo e(old('address.street', config('gym.address.street'))); ?>" maxlength="200" required>
            </div>

            <div class="form-row">
                <label for="locality">City</label>
                <input type="text" id="locality" name="address[locality]" value="<?php echo e(old('address.locality', config('gym.address.locality'))); ?>" maxlength="80" required>
            </div>

            <div class="form-row">
                <label for="region">State</label>
                <input type="text" id="region" name="address[region]" value="<?php echo e(old('address.region', config('gym.address.region'))); ?>" maxlength="80" required>
            </div>

            <div class="form-row span-2">
                <label for="maps_url">Google Maps link <small>(optional)</small></label>
                <input type="url" id="maps_url" name="address[maps_url]" value="<?php echo e(old('address.maps_url', config('gym.address.maps_url'))); ?>" maxlength="600" placeholder="https://maps.app.goo.gl/...">
                <small>Open your gym on Google Maps, tap Share → Copy link, and paste it here. "Get directions" and "Visit us" buttons will open this exact place. Leave empty to search by the address above.</small>
                <?php $__errorArgs = ['address.maps_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </section>

        
        <section class="settings-card">
            <h2>Opening hours</h2>
            <p class="settings-note">Add one row for each set of days with the same timing.</p>

            <div class="repeat-list" id="hoursList">
                <?php $__currentLoopData = $hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('admin.site._hours-row', ['i' => $i, 'row' => $row], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button type="button" class="btn-row-add" data-add-row="hoursList">+ Add timing row</button>

            <template id="hoursListTemplate">
                <?php echo $__env->make('admin.site._hours-row', ['i' => '__i__', 'row' => ['from' => 'Mo', 'to' => 'Fr', 'opens' => '', 'closes' => '']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </template>
        </section>

        
        <section class="settings-card">
            <h2>Social media</h2>
            <p class="settings-note">Leave empty to hide the icon on the website.</p>

            <div class="form-row">
                <label for="instagram">Instagram link <small>(optional)</small></label>
                <input type="url" id="instagram" name="social[instagram]" value="<?php echo e(old('social.instagram', config('gym.social.instagram'))); ?>" placeholder="https://instagram.com/yourgym">
            </div>

            <div class="form-row">
                <label for="facebook">Facebook link <small>(optional)</small></label>
                <input type="url" id="facebook" name="social[facebook]" value="<?php echo e(old('social.facebook', config('gym.social.facebook'))); ?>" placeholder="https://facebook.com/yourgym">
            </div>
        </section>

        
        <section class="settings-card" id="about-gym">
            <div class="settings-card-head">
                <div>
                    <h2>About the gym</h2>
                    <p class="settings-note">The "Our approach" section of the About page, plus any extra sections you add below it.</p>
                </div>
                <a href="<?php echo e(route('admin.about-sections.create')); ?>" class="btn-admin-small">+ Add section</a>
            </div>

            <div class="form-row span-2">
                <label for="about_title">Heading</label>
                <input type="text" id="about_title" name="about_title" value="<?php echo e(old('about_title', config('gym.about_title'))); ?>" maxlength="150" required>
            </div>

            <div class="form-row span-2">
                <label for="about_story">Description</label>
                <textarea id="about_story" name="about_story" rows="8" maxlength="5000" required><?php echo e(old('about_story', $story)); ?></textarea>
                <small>Leave an empty line between paragraphs.</small>
            </div>

            <div class="form-row">
                <label for="years_running">Years running</label>
                <input type="number" id="years_running" name="years_running" min="0" value="<?php echo e(old('years_running', config('gym.years_running'))); ?>" required>
                <small>Shown in the "years coaching" box next to the photo.</small>
            </div>

            <?php $photo = \App\Support\SiteSettings::aboutImage('main'); ?>
            <div class="form-row about-photo-field">
                <label for="about_image_main">Photo <small>(optional)</small></label>
                <?php if($photo && isset($photo['url'])): ?>
                    <img src="<?php echo e($photo['url']); ?>" alt="" class="about-photo-preview">
                <?php elseif($photo): ?>
                    <img src="<?php echo e(asset(config('site-images.' . $photo['site'] . '.sm'))); ?>" alt="" class="about-photo-preview">
                <?php else: ?>
                    <span class="about-photo-preview about-photo-hidden">No photo</span>
                <?php endif; ?>
                <input type="file" id="about_image_main" name="about_image_main" accept="image/jpeg,image/png,image/webp">
                <select name="about_image_main_mode" aria-label="Photo option">
                    <option value="keep">Keep current photo</option>
                    <option value="default">Use default photo</option>
                    <option value="hide">No photo</option>
                </select>
                <small>A new upload replaces the current photo. <?php echo e(\App\Support\ImageUpload::HINT); ?></small>
                <?php $__errorArgs = ['about_image_main'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="about-sections-list">
                <h3>Extra sections</h3>
                <?php $__empty_1 = true; $__currentLoopData = $aboutSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="about-section-row">
                        <?php if($section->image): ?>
                            <img src="<?php echo e($section->imageUrl()); ?>" alt="" class="service-thumb" style="<?php echo e($section->imageFocus()); ?>">
                        <?php else: ?>
                            <span class="service-thumb service-thumb-empty"><?php echo e(mb_strtoupper(mb_substr($section->title, 0, 1))); ?></span>
                        <?php endif; ?>
                        <div class="about-section-text">
                            <span class="person-name"><?php echo e($section->title); ?></span>
                            <span class="person-sub"><?php echo e(\Illuminate\Support\Str::limit($section->body, 80)); ?></span>
                        </div>
                        <span class="status-chip status-<?php echo e($section->is_active ? 'live' : 'hidden'); ?>"><?php echo e($section->is_active ? 'Live' : 'Hidden'); ?></span>
                        <div class="row-actions">
                            <a href="<?php echo e(route('admin.about-sections.edit', $section)); ?>" class="btn-edit">Edit</a>
                            <button type="submit" form="delete-section-<?php echo e($section->id); ?>" class="btn-delete">Delete</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="about-sections-empty">No extra sections yet. Use "+ Add section" to share news, changes or anything new on the About page.</p>
                <?php endif; ?>
            </div>
        </section>

        
        <section class="settings-card">
            <h2>Gym stats</h2>
            <p class="settings-note">The four numbers shown under the home page hero and on the About page.</p>

            <div class="repeat-list">
                <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="repeat-row stat-row">
                        <div class="form-row">
                            <label for="hl-<?php echo e($i); ?>-value">Number</label>
                            <input type="number" id="hl-<?php echo e($i); ?>-value" name="highlights[<?php echo e($i); ?>][value]" min="0" value="<?php echo e($h['value'] ?? ''); ?>" required>
                        </div>
                        <div class="form-row">
                            <label for="hl-<?php echo e($i); ?>-suffix">After number</label>
                            <input type="text" id="hl-<?php echo e($i); ?>-suffix" name="highlights[<?php echo e($i); ?>][suffix]" maxlength="3" value="<?php echo e($h['suffix'] ?? ''); ?>" placeholder="e.g. +">
                        </div>
                        <div class="form-row">
                            <label for="hl-<?php echo e($i); ?>-label">Label</label>
                            <input type="text" id="hl-<?php echo e($i); ?>-label" name="highlights[<?php echo e($i); ?>][label]" maxlength="40" value="<?php echo e($h['label'] ?? ''); ?>" required>
                        </div>
                        <div class="form-row">
                            <label for="hl-<?php echo e($i); ?>-icon">Icon</label>
                            <select id="hl-<?php echo e($i); ?>-icon" name="highlights[<?php echo e($i); ?>][icon]">
                                <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e(($h['icon'] ?? '') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <button type="submit" class="btn-admin">Save changes</button>
    </form>

    <?php $__currentLoopData = $aboutSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="<?php echo e(route('admin.about-sections.destroy', $section)); ?>" id="delete-section-<?php echo e($section->id); ?>" onsubmit="return confirm('Delete this section?');" hidden>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    (function () {
        let counter = 1000;

        document.querySelectorAll('[data-add-row]').forEach((button) => {
            button.addEventListener('click', () => {
                const list = document.getElementById(button.dataset.addRow);
                const template = document.getElementById(button.dataset.addRow + 'Template');
                list.insertAdjacentHTML('beforeend', template.innerHTML.replaceAll('__i__', String(counter++)));
                const field = list.lastElementChild.querySelector('input, select, textarea');
                if (field) field.focus();
            });
        });

        document.addEventListener('click', (event) => {
            const button = event.target.closest('[data-remove-row]');
            if (button) button.closest('.repeat-row').remove();
        });
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\site\edit.blade.php ENDPATH**/ ?>