<?php $__env->startSection('title', 'Gym Offers & Festival Deals | ChampionClub ' . config('gym.address.locality')); ?>
<?php $__env->startSection('description', 'Current festival offers and limited-time membership deals at ChampionClub ' . config('gym.address.locality') . '. Claim an offer before the last date.'); ?>
<?php $__env->startSection('og_image', 'page-offers'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5045da81eea10cd01496aa62d8386994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5045da81eea10cd01496aa62d8386994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-hero','data' => ['image' => 'page-offers','eyebrow' => 'Limited time','title' => 'Event offers','crumb' => 'Offers']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'page-offers','eyebrow' => 'Limited time','title' => 'Event offers','crumb' => 'Offers']); ?>
    Festival specials on memberships and coaching. Grab them before the last date.
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $attributes = $__attributesOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__attributesOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $component = $__componentOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__componentOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>

<section class="offers-section bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap">
        <?php if($offers->isEmpty()): ?>
            <div class="offers-empty mx-auto max-w-2xl border border-white/10 bg-ink-900 p-10 text-center sm:p-14" data-reveal>
                <span class="offers-empty-icon icon-tile size-16"><?php echo \App\Support\SiteHtml::icon('gift', '!text-3xl'); ?></span>
                <h2 class="display-md mt-7 text-white">Sorry, there are currently no offers.</h2>
                <p class="mx-auto mt-4 max-w-md text-white/60">We run special offers on festivals like New Year, Holi, Diwali and Christmas. Check back soon — or ask us about current plans.</p>
                <div class="mt-9 flex flex-wrap justify-center gap-3">
                    <a href="<?php echo e(route('gym.membership')); ?>" class="btn btn-gold">View membership plans</a>
                    <a href="<?php echo e($gymContact->whatsappUrl()); ?>" target="_blank" rel="noopener" class="btn btn-ghost"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> WhatsApp us</a>
                </div>
            </div>
        <?php else: ?>
            <div class="offers-grid">
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-reveal>
                        <?php echo $__env->make('partials.offer-card', ['offer' => $offer], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-12 flex justify-center" data-reveal>
                <a href="<?php echo e($gymContact->whatsappUrl('Hi, I want to know about your current offer')); ?>" target="_blank" rel="noopener" class="btn btn-whatsapp"><?php echo \App\Support\SiteHtml::icon('whatsapp', ''); ?> Get the offer</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\offers.blade.php ENDPATH**/ ?>