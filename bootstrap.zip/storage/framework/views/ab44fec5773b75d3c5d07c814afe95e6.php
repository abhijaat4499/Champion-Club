<?php
    $facility = $facility ?? null;
?>

<div class="form-row">
    <label for="title">Facility name</label>
    <input type="text" id="title" name="title" value="<?php echo e(old('title', $facility->title ?? '')); ?>" placeholder="e.g. Cardio zone" maxlength="80" required>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="display_order">Display order</label>
    <input type="number" id="display_order" name="display_order" min="0" value="<?php echo e(old('display_order', $facility->display_order ?? 0)); ?>" required>
    <?php $__errorArgs = ['display_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="text">Short description</label>
    <textarea id="text" name="text" rows="3" maxlength="300" required><?php echo e(old('text', $facility->text ?? '')); ?></textarea>
    <small>One or two lines shown on the photo.</small>
    <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="image">Photo <small>(optional)</small></label>
    <?php if($facility?->image): ?>
        <img src="<?php echo e($facility->imageUrl()); ?>" alt="<?php echo e($facility->title); ?>" class="service-thumb-preview" style="<?php echo e($facility->imageFocus()); ?>">
    <?php endif; ?>
    <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp">
    <small><?php echo e(\App\Support\ImageUpload::HINT); ?></small>
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="image_position">Image focus</label>
    <select id="image_position" name="image_position">
        <?php $__currentLoopData = \App\Models\Service::IMAGE_POSITIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('image_position', $facility->image_position ?? 'center') === $value ? 'selected' : ''); ?>><?php echo e($position['label']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <small>Which part of the photo stays visible when it is cropped.</small>
</div>

<?php if($facility?->image): ?>
    <div class="checkbox-field">
        <input type="checkbox" id="remove_image" name="remove_image" value="1">
        <label for="remove_image">Remove current photo</label>
    </div>
<?php endif; ?>

<div class="checkbox-field">
    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : ($facility->is_active ?? true)) ? 'checked' : ''); ?>>
    <label for="is_active">Show on website</label>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\facilities\_form.blade.php ENDPATH**/ ?>