<?php
    $reviewErrors = $errors->getBag('review');
    $chosenRating = (int) old('review_rating');
?>

<div id="write-review" class="review-panel mt-14 grid scroll-mt-28 gap-10 border border-white/10 bg-ink-900/85 p-7 backdrop-blur sm:p-10 lg:grid-cols-12 lg:gap-14" data-reveal>
    <div class="lg:col-span-5">
        <p class="eyebrow">Your review</p>
        <h3 class="display-md mt-5 text-white">Trained with us? Tell us how it went.</h3>
        <p class="mt-4 text-white/60">Your words help the next person walk in with confidence. It takes less than a minute.</p>
        <p class="mt-6 flex items-start gap-3 text-sm text-white/50">
            <?php echo \App\Support\SiteHtml::icon('check', 'mt-0.5 shrink-0 text-gold-500'); ?>
            <span>Reviews appear on the website after a quick check by our team.</span>
        </p>
    </div>

    <div class="lg:col-span-7">
        <?php if(session('review_sent')): ?>
            <div class="flex h-full flex-col items-start justify-center gap-4 rounded-sm border border-gold-500/40 bg-gold-500/10 p-8" role="status">
                <span class="flex gap-1 text-xl text-gold-400" aria-hidden="true">
                    <?php for($s = 1; $s <= 5; $s++): ?> <?php echo \App\Support\SiteHtml::icon('star-solid', ''); ?> <?php endfor; ?>
                </span>
                <p class="font-display text-2xl font-semibold text-white">Thank you for your review!</p>
                <p class="text-white/65">We have received it. It will show on the website once our team has checked it.</p>
            </div>
        <?php else: ?>
            <form action="<?php echo e(route('gym.reviews.store')); ?>" method="POST" class="grid gap-5" novalidate>
                <?php echo csrf_field(); ?>

                <div class="hidden" aria-hidden="true">
                    <label for="review-website">Leave this empty</label>
                    <input type="text" id="review-website" name="website" tabindex="-1" autocomplete="off">
                </div>

                <div>
                    <label for="review-name" class="field-label text-white/80">Your name</label>
                    <input type="text" id="review-name" name="review_name" value="<?php echo e(old('review_name')); ?>" autocomplete="name" maxlength="80" required
                           class="field field-dark" placeholder="Full name"
                           <?php if($reviewErrors->has('review_name')): ?> aria-invalid="true" aria-describedby="review-name-error" <?php endif; ?>>
                    <?php if($reviewErrors->has('review_name')): ?>
                        <span id="review-name-error" class="field-error"><?php echo e($reviewErrors->first('review_name')); ?></span>
                    <?php endif; ?>
                </div>

                <fieldset>
                    <legend class="field-label text-white/80">Your rating</legend>
                    <div class="star-input" <?php if($reviewErrors->has('review_rating')): ?> aria-describedby="review-rating-error" <?php endif; ?>>
                        <?php for($s = 5; $s >= 1; $s--): ?>
                            <input type="radio" id="review-star-<?php echo e($s); ?>" name="review_rating" value="<?php echo e($s); ?>" <?php echo e($chosenRating === $s ? 'checked' : ''); ?> required>
                            <label for="review-star-<?php echo e($s); ?>" title="<?php echo e($s); ?> <?php echo e($s === 1 ? 'star' : 'stars'); ?>">
                                <?php echo \App\Support\SiteHtml::icon('star-solid', ''); ?>
                                <span class="sr-only"><?php echo e($s); ?> <?php echo e($s === 1 ? 'star' : 'stars'); ?></span>
                            </label>
                        <?php endfor; ?>
                    </div>
                    <?php if($reviewErrors->has('review_rating')): ?>
                        <span id="review-rating-error" class="field-error"><?php echo e($reviewErrors->first('review_rating')); ?></span>
                    <?php endif; ?>
                </fieldset>

                <div>
                    <label for="review-quote" class="field-label text-white/80">Your review</label>
                    <textarea id="review-quote" name="review_quote" rows="4" maxlength="600" required
                              class="field field-dark resize-y" placeholder="What do you like about training here?"
                              <?php if($reviewErrors->has('review_quote')): ?> aria-invalid="true" aria-describedby="review-quote-error" <?php endif; ?>><?php echo e(old('review_quote')); ?></textarea>
                    <?php if($reviewErrors->has('review_quote')): ?>
                        <span id="review-quote-error" class="field-error"><?php echo e($reviewErrors->first('review_quote')); ?></span>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-gold mt-1 w-full sm:w-auto sm:justify-self-start">Submit review <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/partials/site/review-form.blade.php ENDPATH**/ ?>