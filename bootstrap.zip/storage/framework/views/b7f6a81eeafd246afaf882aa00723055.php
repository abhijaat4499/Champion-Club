<div class="repeat-row hours-row">
    <div class="form-row">
        <label for="hours-<?php echo e($i); ?>-from">From</label>
        <select id="hours-<?php echo e($i); ?>-from" name="hours[<?php echo e($i); ?>][from]">
            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($code); ?>" <?php echo e(($row['from'] ?? '') === $code ? 'selected' : ''); ?>><?php echo e($day['long']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-row">
        <label for="hours-<?php echo e($i); ?>-to">To</label>
        <select id="hours-<?php echo e($i); ?>-to" name="hours[<?php echo e($i); ?>][to]">
            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($code); ?>" <?php echo e(($row['to'] ?? '') === $code ? 'selected' : ''); ?>><?php echo e($day['long']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-row">
        <label for="hours-<?php echo e($i); ?>-opens">Opens</label>
        <input type="time" id="hours-<?php echo e($i); ?>-opens" name="hours[<?php echo e($i); ?>][opens]" value="<?php echo e($row['opens'] ?? ''); ?>">
    </div>
    <div class="form-row">
        <label for="hours-<?php echo e($i); ?>-closes">Closes</label>
        <input type="time" id="hours-<?php echo e($i); ?>-closes" name="hours[<?php echo e($i); ?>][closes]" value="<?php echo e($row['closes'] ?? ''); ?>">
    </div>
    <button type="button" class="btn-row-remove" data-remove-row aria-label="Remove this timing">Remove</button>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\site\_hours-row.blade.php ENDPATH**/ ?>