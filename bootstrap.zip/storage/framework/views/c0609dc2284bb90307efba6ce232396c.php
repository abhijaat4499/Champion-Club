<?php
    $slide = $slide ?? null;
    $pattern = old('pattern', $slide->pattern ?? 'spotlight');
?>


<div class="form-row span-2">
    <span class="form-label">Pattern</span>
    <div class="pattern-picker" role="radiogroup" aria-label="Pattern">
        <?php $__currentLoopData = \App\Models\HeroSlide::PATTERNS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="pattern-option">
                <input type="radio" name="pattern" value="<?php echo e($value); ?>" <?php echo e($pattern === $value ? 'checked' : ''); ?> required>
                <span class="pattern-preview pattern-preview-<?php echo e($value); ?>" aria-hidden="true"><i></i><i></i><i></i></span>
                <span class="pattern-name"><?php echo e($info['label']); ?></span>
                <span class="pattern-hint"><?php echo e($info['hint']); ?></span>
            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__errorArgs = ['pattern'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-row">
    <label for="label">Small label <small>(optional)</small></label>
    <input type="text" id="label" name="label" value="<?php echo e(old('label', $slide->label ?? '')); ?>" maxlength="80" placeholder="e.g. Personal coaching">
    <small>Short gold text above the heading.</small>
    <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="tab">Tab name</label>
    <input type="text" id="tab" name="tab" value="<?php echo e(old('tab', $slide->tab ?? '')); ?>" maxlength="24" placeholder="e.g. Coaching" required>
    <small>One or two words shown on the slide progress bar.</small>
    <?php $__errorArgs = ['tab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row span-2">
    <label for="title">Heading</label>
    <input type="text" id="title" name="title" value="<?php echo e(old('title', $slide->title ?? '')); ?>" maxlength="160" required>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row span-2">
    <label for="highlight">Gold words in the heading <small>(optional)</small></label>
    <input type="text" id="highlight" name="highlight" value="<?php echo e(old('highlight', $slide->highlight ?? '')); ?>" maxlength="80" placeholder="e.g. refused to quit.">
    <small>Copy a few words exactly from the heading to show them in gold.</small>
    <?php $__errorArgs = ['highlight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row span-2">
    <label for="description">Description <small>(optional)</small></label>
    <textarea id="description" name="description" rows="3" maxlength="400"><?php echo e(old('description', $slide->description ?? '')); ?></textarea>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-row">
    <label for="points_style">Points under the description</label>
    <select id="points_style" name="points_style">
        <?php $__currentLoopData = \App\Models\HeroSlide::POINT_STYLES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('points_style', $slide->points_style ?? 'none') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <small>Capsules are rounded tags; check points are a list with ticks.</small>
</div>

<div class="form-row">
    <label for="image_position">Image focus</label>
    <select id="image_position" name="image_position">
        <?php $__currentLoopData = \App\Models\HeroSlide::POSITIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('image_position', $slide->image_position ?? 'center') === $value ? 'selected' : ''); ?>><?php echo e($position['label']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <small>Which part of the photo stays visible on wide screens and phones. Use Left or Right if the person is on one side.</small>
</div>

<div class="form-row">
    <label for="points">Points <small>(optional, one per line)</small></label>
    <textarea id="points" name="points" rows="4" maxlength="1000" placeholder="Free weights&#10;Lockers & showers"><?php echo e(old('points', $slide->points ?? '')); ?></textarea>
    <?php $__errorArgs = ['points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-row">
    <label for="image">Photo <?php echo e($slide ? '(optional)' : ''); ?></label>
    <?php if($slide?->image): ?>
        <img src="<?php echo e(asset('storage/' . $slide->image)); ?>" alt="" class="hero-photo-preview" style="<?php echo e($slide->focus()); ?>">
    <?php elseif($slide?->site_image): ?>
        <img src="<?php echo e(asset(config('site-images.' . $slide->site_image . '.sm'))); ?>" alt="" class="hero-photo-preview">
    <?php endif; ?>
    <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp" <?php echo e($slide ? '' : 'required'); ?>>
    <small><?php echo e(\App\Support\ImageUpload::HINT); ?> A wide (landscape) photo works best; a smaller copy is made for phones.</small>
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-row">
    <label for="button_text">First button text <small>(optional)</small></label>
    <input type="text" id="button_text" name="button_text" value="<?php echo e(old('button_text', $slide->button_text ?? '')); ?>" maxlength="40" placeholder="e.g. Book a free trial">
    <?php $__errorArgs = ['button_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="button_target">First button goes to</label>
    <select id="button_target" name="button_target">
        <option value="">—</option>
        <?php $__currentLoopData = \App\Models\HeroSlide::TARGETS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('button_target', $slide->button_target ?? '') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['button_target'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="button2_text">Second button text <small>(optional)</small></label>
    <input type="text" id="button2_text" name="button2_text" value="<?php echo e(old('button2_text', $slide->button2_text ?? '')); ?>" maxlength="40" placeholder="e.g. Chat with us">
    <?php $__errorArgs = ['button2_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="button2_target">Second button goes to</label>
    <select id="button2_target" name="button2_target">
        <option value="">—</option>
        <?php $__currentLoopData = \App\Models\HeroSlide::TARGETS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('button2_target', $slide->button2_target ?? '') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['button2_target'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="display_order">Display order</label>
    <input type="number" id="display_order" name="display_order" min="0" value="<?php echo e(old('display_order', $slide->display_order ?? 0)); ?>" required>
</div>

<div class="checkbox-field">
    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : ($slide->is_active ?? true)) ? 'checked' : ''); ?>>
    <label for="is_active">Show on the home page</label>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/hero/_form.blade.php ENDPATH**/ ?>