<?php
    $section = $section ?? null;
?>

<div class="form-row">
    <label for="eyebrow">Small label <small>(optional)</small></label>
    <input type="text" id="eyebrow" name="eyebrow" value="<?php echo e(old('eyebrow', $section->eyebrow ?? '')); ?>" placeholder="e.g. What's new" maxlength="60">
    <small>Short gold text shown above the heading.</small>
    <?php $__errorArgs = ['eyebrow'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="display_order">Display order</label>
    <input type="number" id="display_order" name="display_order" min="0" value="<?php echo e(old('display_order', $section->display_order ?? 0)); ?>" required>
    <?php $__errorArgs = ['display_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row span-2">
    <label for="title">Heading</label>
    <input type="text" id="title" name="title" value="<?php echo e(old('title', $section->title ?? '')); ?>" placeholder="e.g. Our new recovery zone is open" maxlength="150" required>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="body">Text</label>
    <textarea id="body" name="body" rows="9" maxlength="8000" required><?php echo e(old('body', $section->body ?? '')); ?></textarea>
    <small>Leave an empty line between paragraphs. A short line on its own (without a full stop) becomes a sub-heading.</small>
    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="image">Photo <small>(optional)</small></label>
    <?php if($section?->image): ?>
        <img src="<?php echo e($section->imageUrl()); ?>" alt="<?php echo e($section->title); ?>" class="service-thumb-preview" style="<?php echo e($section->imageFocus()); ?>">
    <?php endif; ?>
    <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp">
    <small><?php echo e(\App\Support\ImageUpload::HINT); ?> Without a photo the text uses the full width.</small>
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="image_position">Image focus</label>
    <select id="image_position" name="image_position">
        <?php $__currentLoopData = \App\Models\Service::IMAGE_POSITIONS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('image_position', $section->image_position ?? 'center') === $value ? 'selected' : ''); ?>><?php echo e($position['label']); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <small>Which part of the photo stays visible when it is cropped.</small>
</div>

<?php if($section?->image): ?>
    <div class="checkbox-field">
        <input type="checkbox" id="remove_image" name="remove_image" value="1">
        <label for="remove_image">Remove current photo</label>
    </div>
<?php endif; ?>

<div class="checkbox-field">
    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : ($section->is_active ?? true)) ? 'checked' : ''); ?>>
    <label for="is_active">Show on the About page</label>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/about-sections/_form.blade.php ENDPATH**/ ?>