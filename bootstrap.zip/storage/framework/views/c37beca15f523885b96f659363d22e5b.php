<?php $__env->startSection('title', 'Trainers'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Trainers','icon' => 'trainers']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Trainers','icon' => 'trainers']); ?>
        <a href="<?php echo e(route('admin.trainers.create')); ?>" class="btn-admin-small">+ Add Trainer</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="admin-table">
        <thead>
            <tr>
                <th class="col-order">Order</th>
                <th>Trainer</th>
                <th>Bio</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="col-order"><span class="order-chip"><?php echo e($trainer->display_order); ?></span></td>
                    <td>
                        <div class="person-cell">
                            <?php if($trainer->photo): ?>
                                <img src="<?php echo e(asset('storage/' . $trainer->photo)); ?>" alt="<?php echo e($trainer->name); ?>" class="trainer-thumb">
                            <?php else: ?>
                                <span class="trainer-thumb-placeholder"><?php echo e($trainer->initials()); ?></span>
                            <?php endif; ?>
                            <div>
                                <span class="person-name"><?php echo e($trainer->name); ?></span>
                                <span class="person-sub"><?php echo e($trainer->role); ?></span>
                            </div>
                        </div>
                    </td>
                    <td class="col-bio"><?php echo e(\Illuminate\Support\Str::limit($trainer->bio, 90)); ?></td>
                    <td class="text-right">
                        <div class="row-actions">
                            <a href="<?php echo e(route('admin.trainers.edit', $trainer)); ?>" class="btn-edit">Edit</a>

                            <form action="<?php echo e(route('admin.trainers.destroy', $trainer)); ?>" method="POST"
                                  onsubmit="return confirm('Delete this trainer?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="table-empty">No trainers yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/trainers/index.blade.php ENDPATH**/ ?>