<?php
    $theme = $theme ?? 'dark';
    $fieldClass = $theme === 'dark' ? 'field field-dark' : 'field field-light';
    $labelClass = $theme === 'dark' ? 'field-label text-white/80' : 'field-label text-ink-950';
    $defaultInterest = $interest ?? 'trial';
    $selectedInterest = old('interest', request('interest', $defaultInterest));
    $formId = $formId ?? 'lead';
    $button = $button ?? 'Claim my free session';
    $booking = $booking ?? null;
?>

<form action="<?php echo e(route('store.contact')); ?>" method="POST" class="grid gap-5" novalidate>
    <?php echo csrf_field(); ?>

    <?php if($booking): ?>
        <input type="hidden" name="ref_type" value="<?php echo e($booking['type']); ?>">
        <input type="hidden" name="ref_id" value="<?php echo e($booking['id']); ?>">
        <input type="hidden" name="interest" value="<?php echo e($booking['interest']); ?>">
        <div>
            <span class="<?php echo e($labelClass); ?>">Enquiring about</span>
            <p class="flex items-start gap-3 rounded-sm border px-4 py-3.5 text-[0.95rem] font-semibold <?php echo e($theme === 'dark' ? 'border-gold-500/40 bg-gold-500/10 text-white' : 'border-gold-600/40 bg-gold-500/10 text-ink-950'); ?>">
                <?php echo \App\Support\SiteHtml::icon('check', 'mt-0.5 shrink-0 text-gold-500'); ?>
                <span><?php echo e($booking['subject']); ?></span>
            </p>
        </div>
    <?php endif; ?>

    <div>
        <label for="<?php echo e($formId); ?>-name" class="<?php echo e($labelClass); ?>">Your name</label>
        <input type="text" id="<?php echo e($formId); ?>-name" name="name" value="<?php echo e(old('name')); ?>" autocomplete="name" required
               class="<?php echo e($fieldClass); ?>" placeholder="Full name"
               <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" aria-describedby="<?php echo e($formId); ?>-name-error" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span id="<?php echo e($formId); ?>-name-error" class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <label for="<?php echo e($formId); ?>-phone" class="<?php echo e($labelClass); ?>">Mobile number</label>
        <input type="tel" id="<?php echo e($formId); ?>-phone" name="phone" value="<?php echo e(old('phone')); ?>" autocomplete="tel-national" inputmode="numeric" maxlength="10" required data-phone
               class="<?php echo e($fieldClass); ?>" placeholder="10-digit mobile number"
               <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" aria-describedby="<?php echo e($formId); ?>-phone-error" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span id="<?php echo e($formId); ?>-phone-error" class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if (! ($booking)): ?>
        <div>
            <label for="<?php echo e($formId); ?>-interest" class="<?php echo e($labelClass); ?>">I'm interested in</label>
            <select id="<?php echo e($formId); ?>-interest" name="interest" class="<?php echo e($fieldClass); ?>">
                <?php $__currentLoopData = \App\Models\Contact::INTERESTS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php echo e($selectedInterest == $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    <?php endif; ?>

    <button type="submit" class="btn btn-gold mt-1 w-full"><?php echo e($button); ?> <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></button>
    <p class="text-xs <?php echo e($theme === 'dark' ? 'text-white/45' : 'text-ink-950/55'); ?>">No spam. Our team will get back to you shortly.</p>
</form>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\partials\site\lead-form.blade.php ENDPATH**/ ?>