<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['image', 'eyebrow' => null, 'title', 'crumb' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['image', 'eyebrow' => null, 'title', 'crumb' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="relative isolate flex min-h-[62svh] items-end overflow-hidden bg-ink-950 pt-36 pb-14 sm:min-h-[66svh] lg:min-h-[72vh] lg:pb-20">
    <?php echo \App\Support\SiteHtml::img($image, 'absolute inset-0 -z-20 size-full object-cover animate-ken-burns', true); ?>
    <div class="absolute inset-0 -z-10 bg-gradient-to-t from-ink-950 via-ink-950/70 to-ink-950/35"></div>
    <div class="absolute inset-y-0 left-0 -z-10 w-2/3 bg-gradient-to-r from-ink-950/80 to-transparent"></div>

    <div class="wrap">
        <?php if($crumb): ?>
            <nav aria-label="Breadcrumb" class="mb-6 text-xs font-semibold tracking-[0.18em] text-white/55 uppercase">
                <ol class="flex items-center gap-2">
                    <li><a href="<?php echo e(url('/')); ?>" class="transition hover:text-gold-400">Home</a></li>
                    <li aria-hidden="true">/</li>
                    <li aria-current="page" class="text-gold-400"><?php echo e($crumb); ?></li>
                </ol>
            </nav>
        <?php endif; ?>

        <?php if($eyebrow): ?>
            <p class="eyebrow"><?php echo e($eyebrow); ?></p>
        <?php endif; ?>

        <h1 class="display-xl mt-4 max-w-4xl text-white"><?php echo e($title); ?></h1>

        <?php if($slot->isNotEmpty()): ?>
            <div class="lead mt-6 max-w-2xl text-white/75"><?php echo e($slot); ?></div>
        <?php endif; ?>

        <?php if(isset($actions)): ?>
            <div class="mt-9 flex flex-wrap gap-3"><?php echo e($actions); ?></div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\components\site\page-hero.blade.php ENDPATH**/ ?>