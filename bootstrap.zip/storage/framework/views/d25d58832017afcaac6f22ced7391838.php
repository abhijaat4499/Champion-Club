<?php $__env->startSection('title', 'Testimonials'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Testimonials','icon' => 'testimonials']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Testimonials','icon' => 'testimonials']); ?>
        <a href="<?php echo e(url('/')); ?>#video-reviews" class="btn-logout" target="_blank" rel="noopener">View on website</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <div class="admin-subhead">
        <div>
            <h2>Client reviews</h2>
            <p class="settings-note">Shown in the "What our members say" carousel on the home page.</p>
        </div>
        <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn-admin-small">+ Add Review</a>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th class="col-order">Order</th>
                <th>Member</th>
                <th>Review</th>
                <th>Rating</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="col-order"><span class="order-chip"><?php echo e($review->display_order); ?></span></td>
                    <td>
                        <div class="person-cell">
                            <span class="trainer-thumb-placeholder"><?php echo e($review->initials()); ?></span>
                            <div>
                                <span class="person-name"><?php echo e($review->name); ?></span>
                                <?php if($review->since): ?>
                                    <span class="person-sub">Member since <?php echo e($review->since); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td class="col-bio"><?php echo e(\Illuminate\Support\Str::limit($review->quote, 90)); ?></td>
                    <td class="nowrap"><span class="rating-chip"><?php echo e($review->rating); ?> / 5</span></td>
                    <td>
                        <span class="status-chip status-<?php echo e($review->is_active ? 'live' : 'hidden'); ?>"><?php echo e($review->is_active ? 'Live' : 'Hidden'); ?></span>
                    </td>
                    <td class="text-right">
                        <div class="row-actions">
                            <a href="<?php echo e(route('admin.testimonials.edit', $review)); ?>" class="btn-edit">Edit</a>
                            <form action="<?php echo e(route('admin.testimonials.destroy', $review)); ?>" method="POST" onsubmit="return confirm('Delete this review?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="table-empty">No reviews yet. Add one to show it on the home page.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    
    <div class="admin-subhead admin-subhead-spaced" id="videos">
        <div>
            <h2>Video reviews</h2>
            <p class="settings-note">YouTube videos shown in the "Video reviews" carousel on the home page.</p>
        </div>
        <a href="<?php echo e(route('admin.videos.create')); ?>" class="btn-admin-small">+ Add Video</a>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th class="col-order">Order</th>
                <th>Video</th>
                <th>Member</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="col-order"><span class="order-chip"><?php echo e($video->display_order); ?></span></td>
                    <td>
                        <div class="person-cell">
                            <img src="<?php echo e($video->thumbnailUrl()); ?>" alt="" class="service-thumb">
                            <div>
                                <span class="person-name"><?php echo e($video->title); ?></span>
                                <a href="<?php echo e($video->watchUrl()); ?>" class="person-sub" target="_blank" rel="noopener">Open on YouTube</a>
                            </div>
                        </div>
                    </td>
                    <td><?php echo e($video->name ?: '—'); ?></td>
                    <td>
                        <span class="status-chip status-<?php echo e($video->is_active ? 'live' : 'hidden'); ?>"><?php echo e($video->is_active ? 'Live' : 'Hidden'); ?></span>
                    </td>
                    <td class="text-right">
                        <div class="row-actions">
                            <a href="<?php echo e(route('admin.videos.edit', $video)); ?>" class="btn-edit">Edit</a>
                            <form action="<?php echo e(route('admin.videos.destroy', $video)); ?>" method="POST" onsubmit="return confirm('Delete this video?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="table-empty">No video reviews yet. Add a YouTube link to show it on the home page.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <form method="POST" action="<?php echo e(route('admin.testimonials.youtube')); ?>" class="youtube-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-row">
            <label for="youtube">YouTube channel link</label>
            <input type="url" id="youtube" name="youtube" value="<?php echo e(old('youtube', $youtube)); ?>" placeholder="https://www.youtube.com/@yourgym">
            <small>Used for the "Watch more on YouTube" button under the videos and the YouTube icon in the footer. Leave empty to hide both.</small>
            <?php $__errorArgs = ['youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn-admin-small">Save link</button>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\testimonials\index.blade.php ENDPATH**/ ?>