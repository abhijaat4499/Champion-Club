<?php $__env->startSection('title', 'Offers'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Event Offers','icon' => 'offers']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Event Offers','icon' => 'offers']); ?>
        <a href="<?php echo e(route('gym.offers')); ?>" class="btn-logout" target="_blank" rel="noopener">View on website</a>
        <a href="<?php echo e(route('admin.offers.create')); ?>" class="btn-admin-small">+ Add Offer</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="admin-table">
        <thead>
            <tr>
                <th class="col-order">Order</th>
                <th>Offer</th>
                <th>Price</th>
                <th>Dates</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $status = ! $offer->is_active ? 'hidden' : ($offer->isExpired() ? 'expired' : ($offer->isScheduled() ? 'scheduled' : 'live'));
                ?>
                <tr>
                    <td class="col-order"><span class="order-chip"><?php echo e($offer->display_order); ?></span></td>
                    <td>
                        <span class="person-name"><?php echo e($offer->title); ?></span>
                        <span class="event-badge event-<?php echo e($offer->event); ?>"><?php echo e($offer->eventLabel()); ?><?php echo e($offer->event === 'new_year' ? ' ' . $offer->newYearNumber() : ''); ?></span>
                    </td>
                    <td class="nowrap">
                        <span class="price">₹<?php echo e(number_format($offer->price)); ?></span>
                        <?php if($offer->discountPercent()): ?>
                            <span class="person-sub"><s>₹<?php echo e(number_format($offer->original_price)); ?></s> · <?php echo e($offer->discountPercent()); ?>% off</span>
                        <?php endif; ?>
                    </td>
                    <td class="nowrap">
                        <?php if($offer->starts_on): ?>
                            <?php echo e($offer->starts_on->format('d M')); ?> – <?php echo e($offer->valid_until->format('d M Y')); ?>

                        <?php else: ?>
                            Till <?php echo e($offer->valid_until->format('d M Y')); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="status-chip status-<?php echo e($status); ?>">
                            <?php echo e(['live' => 'Live', 'scheduled' => 'Scheduled', 'expired' => 'Expired', 'hidden' => 'Hidden'][$status]); ?>

                        </span>
                    </td>
                    <td class="text-right">
                        <div class="row-actions">
                            <a href="<?php echo e(route('admin.offers.edit', $offer)); ?>" class="btn-edit">Edit</a>

                            <form action="<?php echo e(route('admin.offers.destroy', $offer)); ?>" method="POST"
                                  onsubmit="return confirm('Delete this offer?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="table-empty">
                        No offers yet.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\offers\index.blade.php ENDPATH**/ ?>