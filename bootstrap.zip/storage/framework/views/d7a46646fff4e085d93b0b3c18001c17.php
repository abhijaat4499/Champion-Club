
<div class="otp-resend" data-resend-wait="<?php echo e($resendWait); ?>">
    <span class="otp-resend-text">Didn't get the code, or did it expire?</span>
    <button type="submit" form="otpResendForm" class="otp-resend-btn" data-resend-btn <?php echo e($resendWait ? 'disabled' : ''); ?>>
        Resend code<span data-resend-timer><?php echo e($resendWait ? ' in ' . $resendWait . 's' : ''); ?></span>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/partials/otp-resend.blade.php ENDPATH**/ ?>