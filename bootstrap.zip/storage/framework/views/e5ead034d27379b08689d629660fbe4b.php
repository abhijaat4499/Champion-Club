<?php
    $event = array_key_exists($offer->event, \App\Models\Offer::EVENTS) ? $offer->event : 'other';
    $until = $offer->valid_until;
    $daysLeft = $offer->daysLeft();
    $discount = $offer->discountPercent();
    $lines = $offer->descriptionLines();

    $newYear = $offer->newYearNumber();

    $greeting = $offer->greeting();
?>

<article class="offer-card offer-<?php echo e($event); ?>">

    
    <div class="offer-deco" aria-hidden="true">
        <?php switch($event):
            case ('new_year'): ?>
                <span class="ny-year"><?php echo e($newYear); ?></span>
                <?php echo \App\Support\SiteHtml::icon('confetti', 'ny-burst ny-burst-1'); ?>
                <?php echo \App\Support\SiteHtml::icon('cheers', 'ny-burst ny-burst-2'); ?>
                <?php echo \App\Support\SiteHtml::icon('sparkle', 'ny-burst ny-burst-3'); ?>
                <span class="ny-confetti"></span>
                <?php break; ?>

            <?php case ('diwali'): ?>
                <span class="dw-toran"></span>
                <span class="dw-rangoli"></span>
                <div class="dw-diyas">
                    <?php for($i = 0; $i < 3; $i++): ?>
                        <?php echo \App\Support\SiteHtml::icon('diya', 'dw-diya'); ?>
                    <?php endfor; ?>
                </div>
                <?php break; ?>

            <?php case ('holi'): ?>
                <span class="holi-splash s1"></span>
                <span class="holi-splash s2"></span>
                <span class="holi-splash s3"></span>
                <span class="holi-splash s4"></span>
                <span class="holi-splash s5"></span>
                <span class="holi-dots"></span>
                <?php echo \App\Support\SiteHtml::icon('palette', 'holi-palette'); ?>
                <?php break; ?>

            <?php case ('christmas'): ?>
                <span class="xm-stripe"></span>
                <span class="xm-snow"></span>
                <span class="xm-tree">
                    <?php echo \App\Support\SiteHtml::icon('xstar', 'xm-star'); ?>
                    <?php echo \App\Support\SiteHtml::icon('xtree', 'xm-leaf'); ?>
                </span>
                <?php echo \App\Support\SiteHtml::icon('snowflake', 'xm-flake'); ?>
                <?php break; ?>

            <?php default: ?>
                <span class="std-icon">
                    <?php echo \App\Support\SiteHtml::icon('gift', ''); ?>
                </span>
        <?php endswitch; ?>
    </div>

    
    <div class="offer-body">
        <span class="offer-greeting"><?php echo e($greeting); ?></span>
        <h3 class="offer-title"><?php echo e($offer->title); ?></h3>

        <div class="offer-price">
            <span class="offer-now">₹<?php echo e(number_format($offer->price)); ?></span>
            <?php if($discount): ?>
                <s class="offer-was">₹<?php echo e(number_format($offer->original_price)); ?></s>
                <span class="offer-off"><?php echo e($discount); ?>% OFF</span>
            <?php endif; ?>
        </div>

        <?php if(count($lines) > 1): ?>
            <ul class="offer-points">
                <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($line); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p class="offer-desc"><?php echo e($lines[0] ?? ''); ?></p>
        <?php endif; ?>

        <div class="offer-foot">
            <span class="offer-deadline">
                <?php echo \App\Support\SiteHtml::icon('clock', ''); ?>
                Valid till <?php echo e($until->format('d M Y')); ?>

                <strong>
                    <?php if($daysLeft <= 0): ?>
                        · Last day today
                    <?php elseif($daysLeft === 1): ?>
                        · 1 day left
                    <?php else: ?>
                        · <?php echo e($daysLeft); ?> days left
                    <?php endif; ?>
                </strong>
            </span>
            <a class="btn offer-cta" href="<?php echo e(route('gym.book.offer', $offer)); ?>">Claim offer</a>
        </div>
    </div>
</article>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\partials\offer-card.blade.php ENDPATH**/ ?>