

<?php $__env->startSection('title', 'Verify Code'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-wrap">
    <form class="auth-card" method="POST" action="<?php echo e(route('admin.password.verify')); ?>">
        <?php echo csrf_field(); ?>
        <h1>Enter Code</h1>

        <?php if(session('success')): ?>
            <p class="auth-sub"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert-error"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-row">
            <label for="otp">6-digit code</label>
            <input type="text" id="otp" name="otp" maxlength="6" inputmode="numeric" required autofocus>
        </div>

        <button type="submit" class="btn-admin">Verify code</button>

        <p class="auth-link"><a href="<?php echo e(route('admin.password.request')); ?>">Use a different email</a></p>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\reset-otp.blade.php ENDPATH**/ ?>