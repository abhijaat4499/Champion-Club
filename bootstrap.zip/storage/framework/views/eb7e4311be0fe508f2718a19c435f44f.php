<?php $__env->startSection('title', 'About ChampionClub — Strength & Conditioning Gym in ' . config('gym.address.locality')); ?>
<?php $__env->startSection('description', 'ChampionClub is a coached strength and conditioning gym in ' . config('gym.address.locality') . ', ' . config('gym.address.region') . '. Learn how we train, who we coach and what makes the floor different.'); ?>
<?php $__env->startSection('og_image', 'page-about'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal5045da81eea10cd01496aa62d8386994 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5045da81eea10cd01496aa62d8386994 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.page-hero','data' => ['image' => 'page-about','eyebrow' => 'About us','title' => 'A gym for people who actually train.','crumb' => 'About']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.page-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'page-about','eyebrow' => 'About us','title' => 'A gym for people who actually train.','crumb' => 'About']); ?>
    ChampionClub is a strength and conditioning gym for people training for their next personal best — not someone else's idea of fit.
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $attributes = $__attributesOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__attributesOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5045da81eea10cd01496aa62d8386994)): ?>
<?php $component = $__componentOriginal5045da81eea10cd01496aa62d8386994; ?>
<?php unset($__componentOriginal5045da81eea10cd01496aa62d8386994); ?>
<?php endif; ?>


<?php $approachPhoto = \App\Support\SiteSettings::aboutImage('main'); ?>
<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap grid gap-12 lg:grid-cols-12 lg:gap-16">
        <div class="lg:col-span-7">
            <p class="eyebrow !text-gold-700" data-reveal>Our approach</p>
            <h2 class="display-lg mt-5" data-reveal><?php echo e(config('gym.about_title')); ?></h2>
            <div class="mt-7 space-y-5 text-[1.05rem] leading-relaxed text-ink-950/70" data-reveal>
                <?php $__currentLoopData = \App\Support\SiteSettings::storyParagraphs(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo nl2br(e($paragraph)); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-10 flex flex-wrap gap-3" data-reveal>
                <a href="<?php echo e(route('gym.services')); ?>" class="btn btn-dark">Explore services <?php echo \App\Support\SiteHtml::icon('arrow', 'btn-arrow'); ?></a>
                <a href="<?php echo e(route('gym.trial')); ?>" class="btn btn-outline-dark">Book a free trial</a>
            </div>
        </div>

        <div class="lg:sticky lg:top-32 lg:col-span-5 lg:self-start" data-reveal="right">
            <?php if($approachPhoto): ?>
                <div class="relative pb-6 pl-6 sm:pb-8 sm:pl-8">
                    <div class="zoom-media overflow-hidden rounded-sm">
                        <?php echo $__env->make('partials.site.about-photo', ['photo' => $approachPhoto, 'class' => 'aspect-[4/5] w-full', 'alt' => 'Training at ChampionClub'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <div class="absolute bottom-0 left-0 bg-ink-950 p-5 text-white shadow-xl sm:p-6">
                        <p class="font-display text-5xl leading-none font-extrabold text-gold-400"><?php echo e(config('gym.years_running')); ?>+</p>
                        <p class="mt-2 text-sm text-white/65">years coaching in <?php echo e(config('gym.address.locality')); ?></p>
                    </div>
                </div>
            <?php else: ?>
                <div class="border-t-4 border-gold-500 bg-ink-950 p-10 text-white shadow-xl">
                    <p class="font-display text-8xl leading-none font-extrabold text-gold-400"><?php echo e(config('gym.years_running')); ?>+</p>
                    <p class="mt-4 text-lg text-white/70">years coaching in <?php echo e(config('gym.address.locality')); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>


<section aria-label="ChampionClub at a glance" class="bg-ink-950 py-12 lg:py-14">
    <div class="wrap grid grid-cols-2 gap-y-10 lg:grid-cols-4">
        <?php $__currentLoopData = config('gym.highlights'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border-l border-white/10 pl-6" data-reveal style="--reveal-delay: <?php echo e($loop->index * 0.08); ?>s">
                <?php echo \App\Support\SiteHtml::icon($h['icon'], 'text-2xl text-gold-500'); ?>
                <p class="mt-4 font-display text-5xl leading-none font-extrabold text-white"><span class="inline-block tabular-nums" data-count="<?php echo e($h['value']); ?>"><?php echo e(number_format($h['value'])); ?></span><?php echo e($h['suffix']); ?></p>
                <p class="mt-2 text-sm text-white/60"><?php echo e($h['label']); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<?php if($services->isNotEmpty()): ?>
<section class="bg-bone-100 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap">
        <div class="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between" data-reveal>
            <div class="max-w-2xl">
                <p class="eyebrow !text-gold-700">What we offer</p>
                <h2 class="display-lg mt-5">Coached services for every goal.</h2>
            </div>
            <a href="<?php echo e(route('gym.services')); ?>" class="link-arrow !text-gold-700">All services <?php echo \App\Support\SiteHtml::icon('arrow', ''); ?></a>
        </div>
        <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div data-reveal style="--reveal-delay: <?php echo e(($loop->index % 3) * 0.08); ?>s">
                    <?php echo $__env->make('partials.site.service-card', ['service' => $service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($trainers->isNotEmpty()): ?>
<section class="border-t border-ink-950/10 bg-bone-50 pt-12 pb-14 text-ink-950 lg:pt-14 lg:pb-16">
    <div class="wrap">
        <div class="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between" data-reveal>
            <div>
                <p class="eyebrow !text-gold-700">The team</p>
                <h2 class="display-lg mt-5">Meet some of our coaches.</h2>
            </div>
            <a href="<?php echo e(route('gym.trainers')); ?>" class="link-arrow !text-gold-700">All coaches <?php echo \App\Support\SiteHtml::icon('arrow', ''); ?></a>
        </div>
        <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div data-reveal style="--reveal-delay: <?php echo e($loop->index * 0.08); ?>s">
                    <?php echo $__env->make('partials.site.trainer-card', ['trainer' => $trainer, 'bioLimit' => 110], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>


<?php $__currentLoopData = $aboutSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $dark = $loop->index % 2 === 0;
        $flip = $loop->index % 2 === 1;
        $blocks = $section->bodyBlocks();
    ?>
    <section class="<?php echo e($dark ? 'bg-ink-950 text-white' : 'border-t border-ink-950/10 bg-bone-100 text-ink-950'); ?> pt-12 pb-14 lg:pt-14 lg:pb-16">
        <div class="wrap">
            <?php if($section->imageUrl()): ?>
                <div class="grid gap-10 lg:grid-cols-12 lg:gap-16">
                    <div class="lg:sticky lg:top-32 lg:col-span-5 lg:self-start <?php echo e($flip ? 'lg:order-2' : ''); ?>" data-reveal="<?php echo e($flip ? 'right' : 'left'); ?>">
                        <div class="zoom-media overflow-hidden rounded-sm">
                            <img src="<?php echo e($section->imageUrl()); ?>" style="<?php echo e($section->imageFocus()); ?>" alt="<?php echo e($section->title); ?>" width="1200" height="1500" loading="lazy" decoding="async" class="aspect-[4/3] w-full object-cover lg:aspect-[4/5]">
                        </div>
                    </div>
                    <div class="lg:col-span-7">
                        <?php if($section->eyebrow): ?>
                            <p class="eyebrow <?php echo e($dark ? '' : '!text-gold-700'); ?>" data-reveal><?php echo e($section->eyebrow); ?></p>
                        <?php endif; ?>
                        <h2 class="display-lg <?php echo e($section->eyebrow ? 'mt-5' : ''); ?>" data-reveal><?php echo e($section->title); ?></h2>
                        <div class="service-copy <?php echo e($dark ? 'service-copy-dark' : ''); ?> mt-8" data-reveal>
                            <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($block['type'] === 'heading'): ?>
                                    <h3><?php echo e($block['text']); ?></h3>
                                <?php else: ?>
                                    <p><?php echo e($block['text']); ?></p>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="grid gap-8 lg:grid-cols-12 lg:gap-16">
                    <div class="lg:sticky lg:top-32 lg:col-span-5 lg:self-start" data-reveal>
                        <?php if($section->eyebrow): ?>
                            <p class="eyebrow <?php echo e($dark ? '' : '!text-gold-700'); ?>"><?php echo e($section->eyebrow); ?></p>
                        <?php endif; ?>
                        <h2 class="display-lg <?php echo e($section->eyebrow ? 'mt-5' : ''); ?>"><?php echo e($section->title); ?></h2>
                        <span class="mt-8 block h-1 w-16 bg-gold-500" aria-hidden="true"></span>
                    </div>
                    <div class="service-copy <?php echo e($dark ? 'service-copy-dark' : ''); ?> lg:col-span-7 lg:pt-2" data-reveal>
                        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($block['type'] === 'heading'): ?>
                                <h3><?php echo e($block['text']); ?></h3>
                            <?php else: ?>
                                <p><?php echo e($block['text']); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('partials.site.cta-band', ['image' => 'gallery-8', 'title' => 'Come see the floor for yourself.', 'text' => 'Walk in, meet the coaches, use the floor. Your first session is on us.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/about.blade.php ENDPATH**/ ?>