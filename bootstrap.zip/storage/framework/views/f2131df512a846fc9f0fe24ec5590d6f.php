<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Homepage','icon' => 'homepage']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Homepage','icon' => 'homepage']); ?>
        <a href="<?php echo e(url('/')); ?>" class="btn-logout" target="_blank" rel="noopener">View on website</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="admin-subhead">
        <div>
            <h2>Hero slides</h2>
            <p class="settings-note">The big sliding banner at the top of the home page. Each slide has its own photo, text, points and buttons.</p>
        </div>
        <a href="<?php echo e(route('admin.hero.create')); ?>" class="btn-admin-small">+ Add Slide</a>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th class="col-order">Order</th>
                <th>Slide</th>
                <th>Pattern</th>
                <th>Points</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="col-order"><span class="order-chip"><?php echo e($slide->display_order); ?></span></td>
                    <td>
                        <div class="person-cell">
                            <?php if($slide->image): ?>
                                <img src="<?php echo e(asset('storage/' . ($slide->image_mobile ?: $slide->image))); ?>" alt="" class="service-thumb" style="<?php echo e($slide->focus()); ?>">
                            <?php elseif($slide->site_image): ?>
                                <img src="<?php echo e(asset(config('site-images.' . $slide->site_image . '.sm'))); ?>" alt="" class="service-thumb">
                            <?php endif; ?>
                            <div>
                                <span class="person-name"><?php echo e(\Illuminate\Support\Str::limit($slide->title, 60)); ?></span>
                                <span class="person-sub">Tab: <?php echo e($slide->tab); ?></span>
                            </div>
                        </div>
                    </td>
                    <td><span class="badge"><?php echo e(\App\Models\HeroSlide::PATTERNS[$slide->patternName()]['label']); ?></span></td>
                    <td class="nowrap"><?php echo e(\App\Models\HeroSlide::POINT_STYLES[$slide->points_style] ?? '—'); ?></td>
                    <td>
                        <span class="status-chip status-<?php echo e($slide->is_active ? 'live' : 'hidden'); ?>"><?php echo e($slide->is_active ? 'Live' : 'Hidden'); ?></span>
                    </td>
                    <td class="text-right">
                        <div class="row-actions">
                            <a href="<?php echo e(route('admin.hero.edit', $slide)); ?>" class="btn-edit">Edit</a>
                            <form action="<?php echo e(route('admin.hero.destroy', $slide)); ?>" method="POST" onsubmit="return confirm('Delete this slide?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="table-empty">No slides yet — the home page shows the default slides until you add one.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/hero/index.blade.php ENDPATH**/ ?>