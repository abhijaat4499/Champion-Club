<?php
    $offer = $offer ?? null;
    $selectedEvent = old('event', $offer->event ?? 'other');
?>


<div class="form-row">
    <span class="form-label">Choose event</span>
    <div class="event-picker" role="radiogroup" aria-label="Choose event">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="event-option event-<?php echo e($value); ?>">
                <input type="radio" name="event" value="<?php echo e($value); ?>" <?php echo e($selectedEvent === $value ? 'checked' : ''); ?> required>
                <span class="event-swatch" aria-hidden="true"></span>
                <span class="event-name"><?php echo e($label); ?></span>
            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__errorArgs = ['event'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<?php $isNewYear = $selectedEvent === 'new_year'; ?>
<div class="form-row" id="newYearRow" <?php if(! $isNewYear): ?> hidden <?php endif; ?>>
    <label for="new_year">Which New Year?</label>
    <input type="number" id="new_year" name="new_year" inputmode="numeric"
           min="<?php echo e($newYearRange[0]); ?>" max="<?php echo e($newYearRange[1]); ?>" step="1"
           value="<?php echo e(old('new_year', $offer->new_year ?? \App\Models\Offer::suggestedNewYear())); ?>"
           placeholder="e.g. <?php echo e(\App\Models\Offer::suggestedNewYear()); ?>" <?php if(! $isNewYear): echo 'disabled'; endif; ?> required>
    <small>Type the year, e.g. <?php echo e(\App\Models\Offer::suggestedNewYear()); ?>. Card will show: <strong id="newYearPreview">Happy New Year <?php echo e(old('new_year', $offer->new_year ?? \App\Models\Offer::suggestedNewYear())); ?></strong></small>
    <?php $__errorArgs = ['new_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<script>
    (function () {
        const row = document.getElementById('newYearRow');
        const input = document.getElementById('new_year');
        const preview = document.getElementById('newYearPreview');

        document.querySelectorAll('input[name="event"]').forEach((radio) => {
            radio.addEventListener('change', () => {
                const isNewYear = radio.value === 'new_year' && radio.checked;
                row.hidden = !isNewYear;
                input.disabled = !isNewYear;
            });
        });

        input.addEventListener('input', () => {
            preview.textContent = 'Happy New Year ' + (input.value || '…');
        });
    })();
</script>

<div class="form-row">
    <label for="title">Offer name</label>
    <input type="text" id="title" name="title" value="<?php echo e(old('title', $offer->title ?? '')); ?>" placeholder="e.g. Diwali Special — 3 months membership" maxlength="120" required>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="starts_on">Start date</label>
    <input type="date" id="starts_on" name="starts_on" value="<?php echo e(old('starts_on', optional($offer?->starts_on)->format('Y-m-d') ?? ($offer ? '' : \App\Models\Offer::today()->format('Y-m-d')))); ?>" required>
    <small>The offer appears on the website from this day.</small>
    <?php $__errorArgs = ['starts_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="valid_until">Last date</label>
    <input type="date" id="valid_until" name="valid_until" value="<?php echo e(old('valid_until', optional($offer?->valid_until)->format('Y-m-d'))); ?>" required>
    <?php $__errorArgs = ['valid_until'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="price">Offer price (₹)</label>
    <input type="number" id="price" name="price" min="0" value="<?php echo e(old('price', $offer->price ?? '')); ?>" required>
    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="original_price">Original price (₹) <small>(optional)</small></label>
    <input type="number" id="original_price" name="original_price" min="0" value="<?php echo e(old('original_price', $offer->original_price ?? '')); ?>">
    <?php $__errorArgs = ['original_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="description">Description</label>
    <textarea id="description" name="description" rows="5" maxlength="1000" required><?php echo e(old('description', $offer->description ?? '')); ?></textarea>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-row">
    <label for="display_order">Display order</label>
    <input type="number" id="display_order" name="display_order" min="0" value="<?php echo e(old('display_order', $offer->display_order ?? 0)); ?>" required>
    <?php $__errorArgs = ['display_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="alert-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="checkbox-field">
    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : ($offer->is_active ?? true)) ? 'checked' : ''); ?>>
    <label for="is_active">Show on website</label>
</div>
<?php /**PATH C:\xampp\htdocs\apni_gym\resources\views/admin/offers/_form.blade.php ENDPATH**/ ?>