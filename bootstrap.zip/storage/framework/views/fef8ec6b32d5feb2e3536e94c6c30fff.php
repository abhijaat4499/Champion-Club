<?php $__env->startSection('title', 'Upload Photos'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">

    <?php if (isset($component)) { $__componentOriginalcb19cb35a534439097b02b8af91726ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcb19cb35a534439097b02b8af91726ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.page-header','data' => ['title' => 'Upload photos','icon' => 'gallery']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Upload photos','icon' => 'gallery']); ?>
        <a href="<?php echo e(route('admin.gallery.index')); ?>" class="btn-logout">&larr; Back to gallery</a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $attributes = $__attributesOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__attributesOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcb19cb35a534439097b02b8af91726ee)): ?>
<?php $component = $__componentOriginalcb19cb35a534439097b02b8af91726ee; ?>
<?php unset($__componentOriginalcb19cb35a534439097b02b8af91726ee); ?>
<?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert-error settings-errors">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.gallery.store')); ?>" class="plan-form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-row">
            <label for="photos">Photos</label>
            <input type="file" id="photos" name="photos[]" accept="image/jpeg,image/png,image/webp" multiple required>
            <small>Select one or more JPG, PNG or WebP photos (up to 25 MB each, 20 at a time). Large photos are resized and compressed automatically. If a big batch fails, upload fewer photos at once.</small>
        </div>

        <div class="form-row">
            <label for="alt">Alt text for all uploaded photos <small>(optional)</small></label>
            <input type="text" id="alt" name="alt" value="<?php echo e(old('alt')); ?>" maxlength="160" placeholder="e.g. Cardio section with treadmills">
            <small>Leave blank to use the file names; you can edit each photo afterwards.</small>
        </div>

        <div class="form-row">
            <label for="caption">Caption <small>(optional, applied to all)</small></label>
            <input type="text" id="caption" name="caption" value="<?php echo e(old('caption')); ?>" maxlength="160" placeholder="e.g. Cardio section">
        </div>

        <div class="checkbox-field">
            <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e(($errors->any() ? old('is_active') : true) ? 'checked' : ''); ?>>
            <label for="is_active">Publish immediately</label>
        </div>

        <button type="submit" class="btn-admin">Upload</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\apni_gym\resources\views\admin\gallery\create.blade.php ENDPATH**/ ?>